package com.affiyamart.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

import static org.assertj.core.api.Assertions.assertThat;

class JwtUtilTest {

    /** Same style of HS256 key as in application.properties (>= 32 bytes). */
    private static final String SECRET =
            "YWZmaXlhLW1hcnQtY2hvY29sYXRlLXNlY3JldC1rZXktZm9yLWp3dC10b2tlbi1nZW5lcmF0aW9uLTIwMjYtMDA3";

    private final JwtUtil jwtUtil = new JwtUtil(SECRET, 60_000);

    @Test
    void generateToken_containsSubjectAndCustomClaims() {
        String token = jwtUtil.generateToken("admin@affiyamart.com", "AFFIYA Admin", "ROLE_ADMIN", 1L);

        assertThat(jwtUtil.isValid(token)).isTrue();
        assertThat(jwtUtil.extractEmail(token)).isEqualTo("admin@affiyamart.com");

        Claims claims = Jwts.parserBuilder()
                .setSigningKey(Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8)))
                .build()
                .parseClaimsJws(token)
                .getBody();

        assertThat(claims.get("role", String.class)).isEqualTo("ROLE_ADMIN");
        assertThat(claims.get("name", String.class)).isEqualTo("AFFIYA Admin");
        assertThat(((Number) claims.get("uid")).longValue()).isEqualTo(1L);
    }

    @Test
    void isValid_rejectsTamperedToken() {
        String token = jwtUtil.generateToken("user@affiyamart.com", "Demo", "ROLE_USER", 2L);
        char flipped = token.charAt(0) == 'a' ? 'b' : 'a';
        String tampered = flipped + token.substring(1);

        assertThat(jwtUtil.isValid(tampered)).isFalse();
    }

    @Test
    void isValid_rejectsExpiredToken() {
        JwtUtil expiredUtil = new JwtUtil(SECRET, -1000);
        String token = expiredUtil.generateToken("user@affiyamart.com", "Demo", "ROLE_USER", 2L);

        assertThat(expiredUtil.isValid(token)).isFalse();
    }

    @Test
    void isValid_rejectsGarbageAndNull() {
        assertThat(jwtUtil.isValid("not-a-jwt")).isFalse();
        assertThat(jwtUtil.isValid(null)).isFalse();
    }
}

package com.affiyamart.controller;

import com.affiyamart.dto.ProductRequest;
import com.affiyamart.dto.ProductResponse;
import com.affiyamart.exception.GlobalExceptionHandler;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class ProductControllerTest {

    @Mock
    private ProductService productService;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders
                .standaloneSetup(new ProductController(productService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private static ProductResponse productResponse() {
        return new ProductResponse(1L, "Dairy Milk Silk", "Cadbury",
                new BigDecimal("90.00"), 4.8, 120, "images/dairymilk.svg",
                "Silky smooth", true, 1L, "Milk");
    }

    private static String validProductJson() {
        return """
                {
                  "name": "Mars Bar",
                  "brand": "Mars",
                  "price": 45.00,
                  "rating": 4.5,
                  "stock": 100,
                  "imageUrl": "images/snickers.svg",
                  "description": "Caramel and nougat.",
                  "featured": true,
                  "categoryId": 1
                }
                """;
    }

    // ---------- public reads ----------

    @Test
    void list_passesQueryParamsToService() throws Exception {
        when(productService.search("kit", 1L, "Cadbury", "price-asc"))
                .thenReturn(List.of(productResponse()));

        mockMvc.perform(get("/api/products")
                        .param("search", "kit")
                        .param("categoryId", "1")
                        .param("brand", "Cadbury")
                        .param("sort", "price-asc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Dairy Milk Silk"))
                .andExpect(jsonPath("$[0].categoryName").value("Milk"));

        verify(productService).search("kit", 1L, "Cadbury", "price-asc");
    }

    @Test
    void list_usesFeaturedAsDefaultSort() throws Exception {
        when(productService.search(null, null, null, "featured")).thenReturn(List.of());

        mockMvc.perform(get("/api/products"))
                .andExpect(status().isOk());

        verify(productService).search(null, null, null, "featured");
    }

    @Test
    void get_unknownId_returns404Json() throws Exception {
        when(productService.findById(99L))
                .thenThrow(new ResourceNotFoundException("Product", 99L));

        mockMvc.perform(get("/api/products/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.message").value(
                        org.hamcrest.Matchers.containsString("Product not found")));
    }

    @Test
    void featured_returnsList() throws Exception {
        when(productService.featured()).thenReturn(List.of(productResponse()));

        mockMvc.perform(get("/api/products/featured"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].featured").value(true));
    }

    @Test
    void brands_returnsList() throws Exception {
        when(productService.brands()).thenReturn(List.of("Cadbury", "Nestle"));

        mockMvc.perform(get("/api/products/brands"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").value("Cadbury"));
    }

    // ---------- admin writes (validation happens in the controller) ----------

    @Test
    void create_validBody_returns201WithLocation() throws Exception {
        ProductResponse created = new ProductResponse(5L, "Mars Bar", "Mars",
                new BigDecimal("45.00"), 4.5, 100, "images/snickers.svg",
                "Caramel and nougat.", true, 1L, "Milk");
        when(productService.create(any(ProductRequest.class))).thenReturn(created);

        mockMvc.perform(post("/api/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(validProductJson()))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", org.hamcrest.Matchers.endsWith("/5")))
                .andExpect(jsonPath("$.id").value(5))
                .andExpect(jsonPath("$.name").value("Mars Bar"));
    }

    @Test
    void create_invalidBody_returns400WithFieldErrors() throws Exception {
        mockMvc.perform(post("/api/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"price\": 0}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.errors.name").exists())
                .andExpect(jsonPath("$.errors.brand").exists())
                .andExpect(jsonPath("$.errors.price").exists());

        verify(productService, org.mockito.Mockito.never()).create(any());
    }

    @Test
    void delete_returns204AndDelegates() throws Exception {
        mockMvc.perform(delete("/api/products/5"))
                .andExpect(status().isNoContent());

        verify(productService).delete(5L);
    }
}

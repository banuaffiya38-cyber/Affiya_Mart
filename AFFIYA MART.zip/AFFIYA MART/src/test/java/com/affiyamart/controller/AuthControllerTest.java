package com.affiyamart.controller;

import com.affiyamart.dto.AuthResponse;
import com.affiyamart.dto.ForgotPasswordRequest;
import com.affiyamart.dto.LoginRequest;
import com.affiyamart.dto.RegisterRequest;
import com.affiyamart.exception.ApiException;
import com.affiyamart.exception.GlobalExceptionHandler;
import com.affiyamart.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AuthControllerTest {

    @Mock
    private AuthService authService;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders
                .standaloneSetup(new AuthController(authService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private static AuthResponse token() {
        return new AuthResponse("jwt-token", 7L, "Fazz",
                "fazz@example.com", "9876543210", "ROLE_USER");
    }

    // ---------- public reads ----------

    @Test
    void ping_isPublicAndReportsRunning() throws Exception {
        mockMvc.perform(get("/api/auth/ping"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.app").value("AFFIYA MART"))
                .andExpect(jsonPath("$.status").value("running"));
    }

    // ---------- register ----------

    @Test
    void register_validBody_returnsToken() throws Exception {
        when(authService.register(any(RegisterRequest.class))).thenReturn(token());

        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "Fazz",
                                  "phone": "9876543210",
                                  "email": "fazz@example.com",
                                  "password": "secret123",
                                  "confirmPassword": "secret123"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.role").value("ROLE_USER"));
    }

    @Test
    void register_shortPassword_returns400WithFieldError() throws Exception {
        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "Fazz",
                                  "phone": "9876543210",
                                  "email": "fazz@example.com",
                                  "password": "abc",
                                  "confirmPassword": "abc"
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.errors.password").exists());

        verify(authService, never()).register(any());
    }

    @Test
    void register_duplicateEmail_returns409() throws Exception {
        when(authService.register(any(RegisterRequest.class)))
                .thenThrow(new ApiException("An account with this email already exists",
                        HttpStatus.CONFLICT));

        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "Fazz",
                                  "phone": "9876543210",
                                  "email": "fazz@example.com",
                                  "password": "secret123",
                                  "confirmPassword": "secret123"
                                }
                                """))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.status").value(409))
                .andExpect(jsonPath("$.message").value(
                        "An account with this email already exists"));
    }

    // ---------- login ----------

    @Test
    void login_success_returnsToken() throws Exception {
        when(authService.login(any(LoginRequest.class))).thenReturn(token());

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email": "fazz@example.com", "password": "secret123"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.email").value("fazz@example.com"));
    }

    @Test
    void login_invalidEmailFormat_returns400() throws Exception {
        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email": "not-an-email", "password": "secret123"}
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.email").exists());

        verify(authService, never()).login(any());
    }

    @Test
    void login_wrongCredentials_returns401() throws Exception {
        when(authService.login(any(LoginRequest.class)))
                .thenThrow(new ApiException("Invalid email or password",
                        HttpStatus.UNAUTHORIZED));

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email": "fazz@example.com", "password": "wrong"}
                                """))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Invalid email or password"));
    }

    // ---------- forgot password ----------

    @Test
    void forgotPassword_unknownEmail_returns404() throws Exception {
        when(authService.forgotPassword(any(ForgotPasswordRequest.class)))
                .thenThrow(new ApiException("No account found for this email",
                        HttpStatus.NOT_FOUND));

        mockMvc.perform(post("/api/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email": "nobody@affiyamart.com"}
                                """))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("No account found for this email"));
    }

    @Test
    void forgotPassword_success_returnsTemporaryPasswordMessage() throws Exception {
        when(authService.forgotPassword(any(ForgotPasswordRequest.class)))
                .thenReturn(new com.affiyamart.dto.MessageResponse(
                        "Password reset OK. Temporary password for fazz@example.com: Abc123@#"));

        mockMvc.perform(post("/api/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"email": "fazz@example.com"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value(
                        org.hamcrest.Matchers.containsString("Temporary password")));
    }
}

package com.affiyamart.mapper;

import com.affiyamart.dto.CartItemResponse;
import com.affiyamart.dto.OrderResponse;
import com.affiyamart.dto.ProductResponse;
import com.affiyamart.entity.CartItem;
import com.affiyamart.entity.Category;
import com.affiyamart.entity.Order;
import com.affiyamart.entity.OrderItem;
import com.affiyamart.entity.Product;
import com.affiyamart.entity.User;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class MapperTest {

    private static User user() {
        return new User("Fazz", "9876543210", "fazz@example.com", "hash");
    }

    private static Category category(Long id, String name) {
        Category category = new Category(name, "desc", "images/cat.svg");
        category.setId(id);
        return category;
    }

    private static Product product(Long id, BigDecimal price, Category category) {
        Product product = new Product("KitKat", "Nestle", price, 4.6, 180,
                "images/kitkat.svg", "Crispy wafer", true, category);
        product.setId(id);
        return product;
    }

    @Test
    void toProductResponse_flattensCategory() {
        ProductResponse response = Mapper.toProductResponse(
                product(3L, new BigDecimal("40.00"), category(4L, "Wafer")));

        assertThat(response.id()).isEqualTo(3L);
        assertThat(response.categoryId()).isEqualTo(4L);
        assertThat(response.categoryName()).isEqualTo("Wafer");
        assertThat(response.price()).isEqualByComparingTo("40.00");
    }

    @Test
    void toProductResponse_handlesNullCategory() {
        ProductResponse response = Mapper.toProductResponse(
                product(3L, new BigDecimal("40.00"), null));

        assertThat(response.categoryId()).isNull();
        assertThat(response.categoryName()).isNull();
    }

    @Test
    void nullEntitiesMapToNull() {
        assertThat(Mapper.toProductResponse(null)).isNull();
        assertThat(Mapper.toCategoryResponse(null, 5)).isNull();
        assertThat(Mapper.toUserResponse(null)).isNull();
    }

    @Test
    void toCartItemResponse_computesSubtotal() {
        CartItem item = new CartItem(user(),
                product(5L, new BigDecimal("40.00"), category(1L, "Milk")), 3);
        item.setId(11L);

        CartItemResponse response = Mapper.toCartItemResponse(item);

        assertThat(response.id()).isEqualTo(11L);
        assertThat(response.productId()).isEqualTo(5L);
        assertThat(response.quantity()).isEqualTo(3);
        assertThat(response.subtotal()).isEqualByComparingTo("120.00");
        assertThat(response.categoryName()).isEqualTo("Milk");
    }

    @Test
    void toOrderResponse_mapsItemsAndTotals() {
        Order order = new Order();
        order.setId(9L);
        order.setOrderNumber("AFM-20260922-1234");
        order.setCustomerName("Fazz");
        order.setPhone("9876543210");
        order.setEmail("fazz@example.com");
        order.setAddress("12 Cocoa Lane");
        order.setCity("Chennai");
        order.setPincode("600001");
        order.setTotalAmount(new BigDecimal("80.00"));
        order.setStatus("PLACED");
        order.setOrderDate(LocalDateTime.of(2026, 9, 22, 10, 30));

        OrderItem item = new OrderItem("KitKat", "images/kitkat.svg",
                new BigDecimal("40.00"), 2, null);
        item.setId(3L);
        order.addItem(item);

        OrderResponse response = Mapper.toOrderResponse(order);

        assertThat(response.id()).isEqualTo(9L);
        assertThat(response.orderNumber()).isEqualTo("AFM-20260922-1234");
        assertThat(response.totalAmount()).isEqualByComparingTo("80.00");
        assertThat(response.status()).isEqualTo("PLACED");
        assertThat(response.items()).hasSize(1);
        assertThat(response.items().get(0).productId()).isNull();
        assertThat(response.items().get(0).subtotal()).isEqualByComparingTo("80.00");
    }

    @Test
    void toProductList_and_toOrderList_mapEveryElement() {
        assertThat(Mapper.toProductList(List.of(
                product(1L, BigDecimal.TEN, null),
                product(2L, BigDecimal.TEN, null)))).hasSize(2);
    }
}

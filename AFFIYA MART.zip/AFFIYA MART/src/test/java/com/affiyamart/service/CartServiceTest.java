package com.affiyamart.service;

import com.affiyamart.dto.CartItemRequest;
import com.affiyamart.dto.CartResponse;
import com.affiyamart.dto.UpdateCartRequest;
import com.affiyamart.entity.CartItem;
import com.affiyamart.entity.Product;
import com.affiyamart.entity.User;
import com.affiyamart.exception.ApiException;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.repository.CartItemRepository;
import com.affiyamart.repository.ProductRepository;
import com.affiyamart.repository.UserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CartServiceTest {

    private static final String EMAIL = "user@affiyamart.com";

    @Mock
    private CartItemRepository cartItemRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private CartService cartService;

    private User user;

    @BeforeEach
    void authenticate() {
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(EMAIL, "n/a"));
        user = new User("Demo Customer", "9111111111", EMAIL, "hash");
        user.setId(1L);
    }

    @AfterEach
    void clearContext() {
        SecurityContextHolder.clearContext();
    }

    // ---------- helpers ----------

    private void stubCurrentUser() {
        when(userRepository.findByEmail(EMAIL)).thenReturn(Optional.of(user));
    }

    private static Product product(Long id, String name, String price, int stock) {
        Product product = new Product(name, "Nestle", new BigDecimal(price), 4.5, stock,
                "images/x.svg", "desc", false, null);
        product.setId(id);
        return product;
    }

    private static Product productWithCategory(Long id, String name, String price, int stock) {
        com.affiyamart.entity.Category cat = new com.affiyamart.entity.Category(
                "Milk", "desc", "img");
        cat.setId(1L);
        Product product = new Product(name, "Nestle", new BigDecimal(price), 4.5, stock,
                "images/x.svg", "desc", false, cat);
        product.setId(id);
        return product;
    }

    // ---------- getCart ----------

    @Test
    void getCart_computesTotals() {
        stubCurrentUser();
        Product kitkat = productWithCategory(1L, "KitKat", "40.00", 10);
        Product milkybar = productWithCategory(2L, "Milkybar", "30.00", 10);

        CartItem first = new CartItem(user, kitkat, 2);
        first.setId(11L);
        CartItem second = new CartItem(user, milkybar, 1);
        second.setId(12L);

        when(cartItemRepository.findByUser(user)).thenReturn(List.of(first, second));

        CartResponse cart = cartService.getCart();

        assertThat(cart.count()).isEqualTo(2);
        assertThat(cart.total()).isEqualByComparingTo("110.00");
        assertThat(cart.items().get(0).subtotal()).isEqualByComparingTo("80.00");
        assertThat(cart.items().get(1).subtotal()).isEqualByComparingTo("30.00");
    }

    @Test
    void getCart_emptyCart_returnsZeroTotals() {
        stubCurrentUser();
        when(cartItemRepository.findByUser(user)).thenReturn(List.of());

        CartResponse cart = cartService.getCart();

        assertThat(cart.count()).isZero();
        assertThat(cart.total()).isEqualByComparingTo("0");
    }

    // ---------- add ----------

    @Test
    void add_newLine_savesRequestedQuantity() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 10);
        when(productRepository.findById(1L)).thenReturn(Optional.of(kitkat));
        when(cartItemRepository.findByUserAndProductId(user, 1L)).thenReturn(Optional.empty());

        CartItem[] saved = new CartItem[1];
        when(cartItemRepository.save(any(CartItem.class))).thenAnswer(invocation -> {
            CartItem item = invocation.getArgument(0);
            item.setId(99L);
            saved[0] = item;
            return item;
        });
        when(cartItemRepository.findByUser(user)).thenAnswer(invocation -> List.of(saved[0]));

        CartResponse cart = cartService.add(new CartItemRequest(1L, 2));

        assertThat(saved[0].getQuantity()).isEqualTo(2);
        assertThat(cart.count()).isEqualTo(1);
        assertThat(cart.total()).isEqualByComparingTo("80.00");
    }

    @Test
    void add_existingLine_increasesQuantity() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 10);
        CartItem existing = new CartItem(user, kitkat, 1);
        existing.setId(11L);

        when(productRepository.findById(1L)).thenReturn(Optional.of(kitkat));
        when(cartItemRepository.findByUserAndProductId(user, 1L))
                .thenReturn(Optional.of(existing));
        when(cartItemRepository.save(any(CartItem.class))).thenAnswer(inv -> inv.getArgument(0));
        when(cartItemRepository.findByUser(user)).thenReturn(List.of(existing));

        cartService.add(new CartItemRequest(1L, 2));

        assertThat(existing.getQuantity()).isEqualTo(3);
    }

    @Test
    void add_insufficientStock_rejected() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 5);
        when(productRepository.findById(1L)).thenReturn(Optional.of(kitkat));

        assertThatThrownBy(() -> cartService.add(new CartItemRequest(1L, 6)))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("Only 5 in stock");

        verify(cartItemRepository, never()).save(any());
    }

    @Test
    void add_exceedingCombinedStock_rejected() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 5);
        CartItem existing = new CartItem(user, kitkat, 4);
        existing.setId(11L);

        when(productRepository.findById(1L)).thenReturn(Optional.of(kitkat));
        when(cartItemRepository.findByUserAndProductId(user, 1L))
                .thenReturn(Optional.of(existing));

        assertThatThrownBy(() -> cartService.add(new CartItemRequest(1L, 2)))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("Only 5 in stock");

        verify(cartItemRepository, never()).save(any());
    }

    @Test
    void add_unknownProduct_throws404() {
        stubCurrentUser();
        when(productRepository.findById(42L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> cartService.add(new CartItemRequest(42L, 1)))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- updateQuantity ----------

    @Test
    void updateQuantity_zero_removesLine() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 10);
        CartItem item = new CartItem(user, kitkat, 3);
        item.setId(11L);

        when(cartItemRepository.findById(11L)).thenReturn(Optional.of(item));
        when(cartItemRepository.findByUser(user)).thenReturn(List.of());

        CartResponse cart = cartService.updateQuantity(11L, new UpdateCartRequest(0));

        verify(cartItemRepository).delete(item);
        assertThat(cart.count()).isZero();
    }

    @Test
    void updateQuantity_updatesQuantity() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 10);
        CartItem item = new CartItem(user, kitkat, 3);
        item.setId(11L);

        when(cartItemRepository.findById(11L)).thenReturn(Optional.of(item));
        when(cartItemRepository.save(any(CartItem.class))).thenAnswer(inv -> inv.getArgument(0));
        when(cartItemRepository.findByUser(user)).thenReturn(List.of(item));

        CartResponse cart = cartService.updateQuantity(11L, new UpdateCartRequest(5));

        assertThat(item.getQuantity()).isEqualTo(5);
        assertThat(cart.total()).isEqualByComparingTo("200.00");
    }

    @Test
    void updateQuantity_exceedingStock_rejected() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 5);
        CartItem item = new CartItem(user, kitkat, 1);
        item.setId(11L);

        when(cartItemRepository.findById(11L)).thenReturn(Optional.of(item));

        assertThatThrownBy(() -> cartService.updateQuantity(11L, new UpdateCartRequest(9)))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("Only 5 in stock");
    }

    @Test
    void updateQuantity_otherUsersLine_rejected() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 10);
        User other = new User("Other", "9000000000", "other@affiyamart.com", "hash");
        other.setId(99L);
        CartItem item = new CartItem(other, kitkat, 1);
        item.setId(11L);

        when(cartItemRepository.findById(11L)).thenReturn(Optional.of(item));

        assertThatThrownBy(() -> cartService.updateQuantity(11L, new UpdateCartRequest(2)))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("does not belong to you");
    }

    @Test
    void updateQuantity_unknownItem_throws404() {
        stubCurrentUser();
        when(cartItemRepository.findById(55L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> cartService.updateQuantity(55L, new UpdateCartRequest(1)))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- remove / clear / count ----------

    @Test
    void remove_deletesOwnedLine() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 10);
        CartItem item = new CartItem(user, kitkat, 2);
        item.setId(11L);

        when(cartItemRepository.findById(11L)).thenReturn(Optional.of(item));
        when(cartItemRepository.findByUser(user)).thenReturn(List.of());

        CartResponse cart = cartService.remove(11L);

        verify(cartItemRepository).delete(item);
        assertThat(cart.count()).isZero();
    }

    @Test
    void remove_otherUsersLine_rejected() {
        stubCurrentUser();
        Product kitkat = product(1L, "KitKat", "40.00", 10);
        User other = new User("Other", "9000000000", "other@affiyamart.com", "hash");
        other.setId(99L);
        CartItem item = new CartItem(other, kitkat, 1);
        item.setId(11L);

        when(cartItemRepository.findById(11L)).thenReturn(Optional.of(item));

        assertThatThrownBy(() -> cartService.remove(11L))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("does not belong to you");

        verify(cartItemRepository, never()).delete(any());
    }

    @Test
    void clear_deletesAllLinesOfUser() {
        doNothing().when(cartItemRepository).deleteByUser(user);

        cartService.clear(user);

        verify(cartItemRepository).deleteByUser(user);
    }

    @Test
    void count_returnsNumberOfLines() {
        stubCurrentUser();
        when(cartItemRepository.countByUser(user)).thenReturn(5L);

        assertThat(cartService.count()).isEqualTo(5);
    }
}

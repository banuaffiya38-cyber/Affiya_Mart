package com.affiyamart.service;

import com.affiyamart.dto.AuthResponse;
import com.affiyamart.dto.ForgotPasswordRequest;
import com.affiyamart.dto.LoginRequest;
import com.affiyamart.dto.MessageResponse;
import com.affiyamart.dto.RegisterRequest;
import com.affiyamart.dto.UserResponse;
import com.affiyamart.entity.User;
import com.affiyamart.exception.ApiException;
import com.affiyamart.repository.UserRepository;
import com.affiyamart.security.JwtUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private AuthService authService;

    private static User user(Long id) {
        User user = new User("Fazz", "9876543210", "fazz@example.com", "hash");
        user.setId(id);
        user.setRole("ROLE_USER");
        return user;
    }

    // ---------- register ----------

    @Test
    void register_passwordMismatch_rejected() {
        RegisterRequest request = new RegisterRequest("Fazz", "9876543210",
                "fazz@example.com", "secret123", "different");

        assertThatThrownBy(() -> authService.register(request))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("do not match");

        verify(userRepository, never()).save(any());
    }

    @Test
    void register_duplicateEmail_conflict() {
        RegisterRequest request = new RegisterRequest("Fazz", "9876543210",
                "  FAZZ@example.com ", "secret123", "secret123");
        when(userRepository.existsByEmail("fazz@example.com")).thenReturn(true);

        assertThatThrownBy(() -> authService.register(request))
                .isInstanceOf(ApiException.class)
                .satisfies(ex -> assertThat(((ApiException) ex).getStatus())
                        .isEqualTo(HttpStatus.CONFLICT));
    }

    @Test
    void register_success_hashesPasswordLowercasesEmailAndReturnsToken() {
        RegisterRequest request = new RegisterRequest("  Fazz ", "9876543210",
                "  FAZZ@Example.COM ", "secret123", "secret123");

        when(userRepository.existsByEmail("fazz@example.com")).thenReturn(false);
        when(passwordEncoder.encode("secret123")).thenReturn("$2a$HASHED");
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User saved = invocation.getArgument(0);
            saved.setId(7L);
            return saved;
        });
        when(jwtUtil.generateToken(any(), any(), any(), any())).thenReturn("jwt-token");

        AuthResponse response = authService.register(request);

        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(captor.capture());
        User saved = captor.getValue();

        assertThat(saved.getEmail()).isEqualTo("fazz@example.com");
        assertThat(saved.getPassword()).isEqualTo("$2a$HASHED");   // BCrypt hash, not plain
        assertThat(saved.getRole()).isEqualTo("ROLE_USER");
        assertThat(saved.getName()).isEqualTo("Fazz");

        assertThat(response.token()).isEqualTo("jwt-token");
        assertThat(response.id()).isEqualTo(7L);
        assertThat(response.email()).isEqualTo("fazz@example.com");
        assertThat(response.role()).isEqualTo("ROLE_USER");
    }

    // ---------- login ----------

    @Test
    void login_success_returnsToken() {
        LoginRequest request = new LoginRequest("  FAZZ@example.com ", "secret123");
        Authentication authentication = new UsernamePasswordAuthenticationToken(
                "fazz@example.com", "secret123");

        when(authenticationManager.authenticate(any())).thenReturn(authentication);
        when(userRepository.findByEmail("fazz@example.com")).thenReturn(Optional.of(user(7L)));
        when(jwtUtil.generateToken(any(), any(), any(), any())).thenReturn("jwt-token");

        AuthResponse response = authService.login(request);

        assertThat(response.token()).isEqualTo("jwt-token");
        assertThat(response.id()).isEqualTo(7L);
        assertThat(response.email()).isEqualTo("fazz@example.com");

        ArgumentCaptor<UsernamePasswordAuthenticationToken> captor =
                ArgumentCaptor.forClass(UsernamePasswordAuthenticationToken.class);
        verify(authenticationManager).authenticate(captor.capture());
        assertThat(captor.getValue().getPrincipal()).isEqualTo("fazz@example.com");
    }

    // ---------- forgot password ----------

    @Test
    void forgotPassword_unknownEmail_404() {
        when(userRepository.findByEmail("nobody@affiyamart.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.forgotPassword(
                new ForgotPasswordRequest("NOBODY@affiyamart.com")))
                .isInstanceOf(ApiException.class)
                .satisfies(ex -> assertThat(((ApiException) ex).getStatus())
                        .isEqualTo(HttpStatus.NOT_FOUND));
    }

    @Test
    void forgotPassword_replacesPasswordWithTemporaryOne() {
        User user = user(7L);
        when(userRepository.findByEmail("fazz@example.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.encode(anyString())).thenReturn("$2a$TEMPHASH");

        MessageResponse response = authService.forgotPassword(
                new ForgotPasswordRequest("  FAZZ@example.com "));

        assertThat(response.message()).contains("Password reset OK");
        assertThat(response.message()).contains("fazz@example.com");
        assertThat(user.getPassword()).isEqualTo("$2a$TEMPHASH");   // temp password stored hashed
        verify(userRepository).save(user);
    }

    // ---------- profile ----------

    @Test
    void profile_returnsPublicUserFields() {
        when(userRepository.findByEmail("fazz@example.com")).thenReturn(Optional.of(user(7L)));

        UserResponse response = authService.profile("fazz@example.com");

        assertThat(response.id()).isEqualTo(7L);
        assertThat(response.name()).isEqualTo("Fazz");
        assertThat(response.role()).isEqualTo("ROLE_USER");
        assertThat(response.createdAt()).isNotNull();
    }

    @Test
    void profile_unknownEmail_404() {
        when(userRepository.findByEmail("ghost@affiyamart.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.profile("ghost@affiyamart.com"))
                .isInstanceOf(ApiException.class)
                .satisfies(ex -> assertThat(((ApiException) ex).getStatus())
                        .isEqualTo(HttpStatus.NOT_FOUND));
    }
}

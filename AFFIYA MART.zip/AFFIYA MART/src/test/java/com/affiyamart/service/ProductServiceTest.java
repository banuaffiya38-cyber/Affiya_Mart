package com.affiyamart.service;

import com.affiyamart.dto.ProductRequest;
import com.affiyamart.dto.ProductResponse;
import com.affiyamart.entity.Category;
import com.affiyamart.entity.Product;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.repository.CategoryRepository;
import com.affiyamart.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private ProductService productService;

    // ---------- helpers ----------

    private static Product product(Long id, String name, String brand, String price,
                                   double rating, int stock, boolean featured) {
        Product product = new Product(name, brand, new BigDecimal(price), rating, stock,
                "images/x.svg", "desc", featured, null);
        product.setId(id);
        return product;
    }

    private static ProductRequest request(String name, Long categoryId) {
        return new ProductRequest(name, "Mars", new BigDecimal("45.00"), 4.5, 100,
                "images/mars.svg", "Caramel", true, categoryId);
    }

    // ---------- search / sort ----------

    @Test
    void search_defaultSort_featuredFirstThenRatingDesc() {
        Product zulu  = product(1L, "Zulu",  "Amul",    "10.00", 4.9, 5, false);
        Product alpha = product(2L, "Alpha", "Nestle",  "40.00", 4.5, 5, true);
        Product mike  = product(3L, "Mike",  "Cadbury", "90.00", 3.0, 5, false);
        when(productRepository.search(null, null, null)).thenReturn(List.of(zulu, alpha, mike));

        List<ProductResponse> result = productService.search(null, null, null, null);

        assertThat(result).extracting(ProductResponse::name)
                .containsExactly("Alpha", "Zulu", "Mike");
    }

    @Test
    void search_priceAscending() {
        Product zulu  = product(1L, "Zulu",  "Amul",   "10.00", 4.9, 5, false);
        Product alpha = product(2L, "Alpha", "Nestle", "40.00", 4.5, 5, false);
        Product mike  = product(3L, "Mike",  "Cadbury", "90.00", 3.0, 5, false);
        when(productRepository.search(null, null, null)).thenReturn(List.of(mike, zulu, alpha));

        List<ProductResponse> result = productService.search(null, null, null, "price-asc");

        assertThat(result).extracting(ProductResponse::name)
                .containsExactly("Zulu", "Alpha", "Mike");
    }

    @Test
    void search_priceDescending() {
        Product zulu  = product(1L, "Zulu",  "Amul",   "10.00", 4.9, 5, false);
        Product alpha = product(2L, "Alpha", "Nestle", "40.00", 4.5, 5, false);
        Product mike  = product(3L, "Mike",  "Cadbury", "90.00", 3.0, 5, false);
        when(productRepository.search(null, null, null)).thenReturn(List.of(zulu, alpha, mike));

        List<ProductResponse> result = productService.search(null, null, null, "price-desc");

        assertThat(result).extracting(ProductResponse::name)
                .containsExactly("Mike", "Alpha", "Zulu");
    }

    @Test
    void search_byRating() {
        Product zulu  = product(1L, "Zulu",  "Amul",   "10.00", 4.9, 5, false);
        Product alpha = product(2L, "Alpha", "Nestle", "40.00", 4.5, 5, false);
        Product mike  = product(3L, "Mike",  "Cadbury", "90.00", 3.0, 5, false);
        when(productRepository.search(null, null, null)).thenReturn(List.of(mike, alpha, zulu));

        List<ProductResponse> result = productService.search(null, null, null, "rating");

        assertThat(result).extracting(ProductResponse::name)
                .containsExactly("Zulu", "Alpha", "Mike");
    }

    @Test
    void search_byName_caseInsensitive() {
        Product zulu  = product(1L, "Zulu",  "Amul",   "10.00", 4.9, 5, false);
        Product alpha = product(2L, "alpha", "Nestle", "40.00", 4.5, 5, false);
        Product mike  = product(3L, "Mike",  "Cadbury", "90.00", 3.0, 5, false);
        when(productRepository.search(null, null, null)).thenReturn(List.of(zulu, alpha, mike));

        List<ProductResponse> result = productService.search(null, null, null, "name");

        assertThat(result).extracting(ProductResponse::name)
                .containsExactly("alpha", "Mike", "Zulu");
    }

    @Test
    void search_passesFiltersToRepository() {
        when(productRepository.search("kit", 1L, "Cadbury")).thenReturn(List.of());

        productService.search("kit", 1L, "Cadbury", "price-asc");

        verify(productRepository).search("kit", 1L, "Cadbury");
    }

    @Test
    void search_blankFiltersBecomeNull() {
        when(productRepository.search(null, null, null)).thenReturn(List.of());

        productService.search("   ", null, "  ", "price-asc");

        verify(productRepository).search(null, null, null);
    }

    // ---------- read single / featured / brands ----------

    @Test
    void findById_returnsProduct() {
        when(productRepository.findById(1L))
                .thenReturn(Optional.of(product(1L, "KitKat", "Nestle", "40.00", 4.6, 180, true)));

        ProductResponse response = productService.findById(1L);

        assertThat(response.name()).isEqualTo("KitKat");
        assertThat(response.brand()).isEqualTo("Nestle");
    }

    @Test
    void findById_unknownId_throws404() {
        when(productRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> productService.findById(99L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("Product not found");
    }

    @Test
    void featured_returnsOnlyFeaturedProducts() {
        when(productRepository.findByFeaturedTrue()).thenReturn(List.of(
                product(1L, "KitKat", "Nestle", "40.00", 4.6, 180, true)));

        assertThat(productService.featured()).hasSize(1);
    }

    @Test
    void brands_returnsDistinctBrands() {
        when(productRepository.findAllBrands()).thenReturn(List.of("Cadbury", "Nestle"));

        assertThat(productService.brands()).containsExactly("Cadbury", "Nestle");
    }

    // ---------- create ----------

    @Test
    void create_savesProductWithCategory() {
        Category milk = new Category("Milk", "desc", "img");
        milk.setId(1L);
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(milk));
        when(productRepository.save(any(Product.class))).thenAnswer(invocation -> {
            Product saved = invocation.getArgument(0);
            saved.setId(10L);
            return saved;
        });

        ProductResponse response = productService.create(request("  Mars Bar  ", 1L));

        assertThat(response.id()).isEqualTo(10L);
        assertThat(response.name()).isEqualTo("Mars Bar");   // trimmed
        assertThat(response.categoryId()).isEqualTo(1L);
        assertThat(response.featured()).isTrue();
    }

    @Test
    void create_unknownCategory_throws404() {
        when(categoryRepository.findById(5L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> productService.create(request("Mars Bar", 5L)))
                .isInstanceOf(ResourceNotFoundException.class);

        verify(productRepository, never()).save(any());
    }

    // ---------- update ----------

    @Test
    void update_appliesNewValues() {
        Product existing = product(1L, "Old Name", "Nestle", "40.00", 4.0, 10, false);
        when(productRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(productRepository.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

        ProductResponse response = productService.update(1L, request("New Name", null));

        assertThat(response.name()).isEqualTo("New Name");
        assertThat(response.price()).isEqualByComparingTo("45.00");
        assertThat(existing.getCategory()).isNull();
    }

    @Test
    void update_unknownId_throws404() {
        when(productRepository.findById(77L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> productService.update(77L, request("X", null)))
                .isInstanceOf(ResourceNotFoundException.class);

        verify(productRepository, never()).save(any());
    }

    // ---------- delete ----------

    @Test
    void delete_removesProduct() {
        Product existing = product(1L, "KitKat", "Nestle", "40.00", 4.6, 180, true);
        when(productRepository.findById(1L)).thenReturn(Optional.of(existing));

        productService.delete(1L);

        verify(productRepository).delete(existing);
    }

    @Test
    void delete_unknownId_throws404() {
        when(productRepository.findById(77L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> productService.delete(77L))
                .isInstanceOf(ResourceNotFoundException.class);

        verify(productRepository, never()).delete(any());
    }
}

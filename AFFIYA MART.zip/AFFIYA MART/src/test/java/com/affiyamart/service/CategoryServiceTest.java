package com.affiyamart.service;

import com.affiyamart.dto.CategoryRequest;
import com.affiyamart.dto.CategoryResponse;
import com.affiyamart.entity.Category;
import com.affiyamart.exception.ApiException;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.repository.CategoryRepository;
import com.affiyamart.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CategoryServiceTest {

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private CategoryService categoryService;

    private static Category category(Long id, String name) {
        Category category = new Category(name, "desc", "images/cat.svg");
        category.setId(id);
        return category;
    }

    @Test
    void findAll_includesProductCounts() {
        Category milk = category(1L, "Milk");
        Category dark = category(2L, "Dark");
        when(categoryRepository.findAll()).thenReturn(List.of(milk, dark));
        when(productRepository.countByCategoryId(1L)).thenReturn(3L);
        when(productRepository.countByCategoryId(2L)).thenReturn(0L);

        List<CategoryResponse> result = categoryService.findAll();

        assertThat(result).hasSize(2);
        assertThat(result.get(0).productCount()).isEqualTo(3);
        assertThat(result.get(1).productCount()).isEqualTo(0);
    }

    @Test
    void findById_returnsCategoryWithCount() {
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category(1L, "Milk")));
        when(productRepository.countByCategoryId(1L)).thenReturn(4L);

        CategoryResponse response = categoryService.findById(1L);

        assertThat(response.name()).isEqualTo("Milk");
        assertThat(response.productCount()).isEqualTo(4);
    }

    @Test
    void findById_unknownId_throws404() {
        when(categoryRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> categoryService.findById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void create_duplicateName_rejected() {
        when(categoryRepository.existsByNameIgnoreCase("Milk")).thenReturn(true);

        assertThatThrownBy(() -> categoryService.create(
                new CategoryRequest("  Milk  ", "desc", "img")))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("already exists");

        verify(categoryRepository, never()).save(any());
    }

    @Test
    void create_savesTrimmedCategory() {
        when(categoryRepository.existsByNameIgnoreCase("Nutty")).thenReturn(false);
        when(categoryRepository.save(any(Category.class))).thenAnswer(invocation -> {
            Category saved = invocation.getArgument(0);
            saved.setId(6L);
            return saved;
        });

        CategoryResponse response = categoryService.create(
                new CategoryRequest("  Nutty  ", "Chocolates with nuts", "images/gift.svg"));

        assertThat(response.id()).isEqualTo(6L);
        assertThat(response.name()).isEqualTo("Nutty");
        assertThat(response.productCount()).isZero();
    }

    @Test
    void update_appliesNewValues() {
        Category existing = category(1L, "Milk");
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(categoryRepository.save(any(Category.class))).thenAnswer(inv -> inv.getArgument(0));
        when(productRepository.countByCategoryId(1L)).thenReturn(2L);

        CategoryResponse response = categoryService.update(1L,
                new CategoryRequest("Creamy Milk", "new desc", "images/new.svg"));

        assertThat(response.name()).isEqualTo("Creamy Milk");
        assertThat(response.description()).isEqualTo("new desc");
        assertThat(response.productCount()).isEqualTo(2);
    }

    @Test
    void delete_blockedWhenProductsUseCategory() {
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category(1L, "Milk")));
        when(productRepository.countByCategoryId(1L)).thenReturn(5L);

        assertThatThrownBy(() -> categoryService.delete(1L))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("products still use this category");

        verify(categoryRepository, never()).delete(any());
    }

    @Test
    void delete_removesEmptyCategory() {
        Category existing = category(2L, "Dark");
        when(categoryRepository.findById(2L)).thenReturn(Optional.of(existing));
        when(productRepository.countByCategoryId(2L)).thenReturn(0L);

        categoryService.delete(2L);

        verify(categoryRepository).delete(existing);
    }
}

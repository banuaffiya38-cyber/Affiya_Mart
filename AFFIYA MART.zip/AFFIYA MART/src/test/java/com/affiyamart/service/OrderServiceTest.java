package com.affiyamart.service;

import com.affiyamart.dto.CartItemResponse;
import com.affiyamart.dto.CartResponse;
import com.affiyamart.dto.CheckoutRequest;
import com.affiyamart.dto.OrderResponse;
import com.affiyamart.entity.Order;
import com.affiyamart.entity.OrderItem;
import com.affiyamart.entity.Product;
import com.affiyamart.entity.User;
import com.affiyamart.exception.ApiException;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.repository.OrderRepository;
import com.affiyamart.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private CartService cartService;

    @InjectMocks
    private OrderService orderService;

    // ---------- helpers ----------

    private static User user(Long id, String role) {
        User user = new User("Demo Customer", "9111111111", "user@affiyamart.com", "hash");
        user.setId(id);
        user.setRole(role);
        return user;
    }

    private static CheckoutRequest checkout() {
        return new CheckoutRequest("Fazz", "9876543210", "fazz@example.com",
                "12 Cocoa Lane", "Chennai", "600001");
    }

    private static CartItemResponse line(Long productId, int quantity, String price) {
        return new CartItemResponse(11L, productId, "KitKat", "Nestle",
                "images/kitkat.svg", new BigDecimal(price), 10, quantity,
                new BigDecimal(price).multiply(BigDecimal.valueOf(quantity)), "Wafer");
    }

    private static Product product(Long id, String price, int stock) {
        Product product = new Product("KitKat", "Nestle", new BigDecimal(price), 4.6,
                stock, "images/kitkat.svg", "Crispy", true, null);
        product.setId(id);
        return product;
    }

    private static Order orderWithItem(User owner) {
        Order order = new Order();
        order.setId(9L);
        order.setOrderNumber("AFM-20260922-1234");
        order.setCustomerName("Fazz");
        order.setPhone("9876543210");
        order.setEmail("fazz@example.com");
        order.setAddress("12 Cocoa Lane");
        order.setCity("Chennai");
        order.setPincode("600001");
        order.setTotalAmount(new BigDecimal("80.00"));
        order.setStatus("PLACED");
        order.setOrderDate(LocalDateTime.of(2026, 9, 22, 10, 30));
        order.setUser(owner);
        order.addItem(new OrderItem("KitKat", "images/kitkat.svg",
                new BigDecimal("40.00"), 2, null));
        return order;
    }

    // ---------- placeOrder ----------

    @Test
    void placeOrder_emptyCart_rejected() {
        when(cartService.getCart()).thenReturn(new CartResponse(List.of(), BigDecimal.ZERO, 0));

        assertThatThrownBy(() -> orderService.placeOrder(checkout()))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("cart is empty");

        verify(orderRepository, never()).save(any());
    }

    @Test
    void placeOrder_success_decrementsStockAndClearsCart() {
        User user = user(1L, "ROLE_USER");
        Product kitkat = product(1L, "40.00", 10);

        when(cartService.getCart()).thenReturn(
                new CartResponse(List.of(line(1L, 2, "40.00")), new BigDecimal("80.00"), 1));
        when(cartService.currentUser()).thenReturn(user);
        when(productRepository.findById(1L)).thenReturn(Optional.of(kitkat));
        when(productRepository.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));
        when(orderRepository.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

        OrderResponse response = orderService.placeOrder(checkout());

        assertThat(response.orderNumber()).startsWith("AFM-");
        assertThat(response.status()).isEqualTo("PLACED");
        assertThat(response.customerName()).isEqualTo("Fazz");
        assertThat(response.totalAmount()).isEqualByComparingTo("80.00");
        assertThat(response.items()).hasSize(1);
        assertThat(response.items().get(0).subtotal()).isEqualByComparingTo("80.00");
        assertThat(kitkat.getStock()).isEqualTo(8);          // stock reduced 10 -> 8
        verify(cartService).clear(user);                     // cart emptied
    }

    @Test
    void placeOrder_insufficientStock_rejectedAndNothingSaved() {
        User user = user(1L, "ROLE_USER");
        Product kitkat = product(1L, "40.00", 1);

        when(cartService.getCart()).thenReturn(
                new CartResponse(List.of(line(1L, 2, "40.00")), new BigDecimal("80.00"), 1));
        when(cartService.currentUser()).thenReturn(user);
        when(productRepository.findById(1L)).thenReturn(Optional.of(kitkat));

        assertThatThrownBy(() -> orderService.placeOrder(checkout()))
                .isInstanceOf(ApiException.class)
                .hasMessageContaining("Not enough stock");

        verify(orderRepository, never()).save(any());
        verify(cartService, never()).clear(any());
        assertThat(kitkat.getStock()).isEqualTo(1);          // unchanged
    }

    @Test
    void placeOrder_productDeletedFromCatalog_throws404() {
        User user = user(1L, "ROLE_USER");

        when(cartService.getCart()).thenReturn(
                new CartResponse(List.of(line(1L, 2, "40.00")), new BigDecimal("80.00"), 1));
        when(cartService.currentUser()).thenReturn(user);
        when(productRepository.findById(1L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> orderService.placeOrder(checkout()))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- myOrders / allOrders ----------

    @Test
    void myOrders_returnsHistoryNewestFirst() {
        User user = user(1L, "ROLE_USER");
        when(cartService.currentUser()).thenReturn(user);
        when(orderRepository.findByUserOrderByOrderDateDesc(user))
                .thenReturn(List.of(orderWithItem(user)));

        List<OrderResponse> orders = orderService.myOrders();

        assertThat(orders).hasSize(1);
        assertThat(orders.get(0).orderNumber()).isEqualTo("AFM-20260922-1234");
        assertThat(orders.get(0).items()).hasSize(1);
    }

    @Test
    void allOrders_returnsEverything() {
        when(orderRepository.findAllByOrderByOrderDateDesc())
                .thenReturn(List.of(orderWithItem(user(1L, "ROLE_USER"))));

        assertThat(orderService.allOrders()).hasSize(1);
    }

    // ---------- byOrderNumber ----------

    @Test
    void byOrderNumber_ownerCanView() {
        User owner = user(1L, "ROLE_USER");
        Order order = orderWithItem(owner);
        when(orderRepository.findByOrderNumber("AFM-20260922-1234"))
                .thenReturn(Optional.of(order));
        when(cartService.currentUser()).thenReturn(owner);

        OrderResponse response = orderService.byOrderNumber("AFM-20260922-1234");

        assertThat(response.orderNumber()).isEqualTo("AFM-20260922-1234");
    }

    @Test
    void byOrderNumber_strangerGets403() {
        Order order = orderWithItem(user(1L, "ROLE_USER"));
        User stranger = user(2L, "ROLE_USER");
        when(orderRepository.findByOrderNumber("AFM-20260922-1234"))
                .thenReturn(Optional.of(order));
        when(cartService.currentUser()).thenReturn(stranger);

        assertThatThrownBy(() -> orderService.byOrderNumber("AFM-20260922-1234"))
                .isInstanceOf(ApiException.class)
                .satisfies(ex -> assertThat(((ApiException) ex).getStatus())
                        .isEqualTo(HttpStatus.FORBIDDEN));
    }

    @Test
    void byOrderNumber_adminCanViewAnyOrder() {
        Order order = orderWithItem(user(1L, "ROLE_USER"));
        User admin = user(2L, "ROLE_ADMIN");
        when(orderRepository.findByOrderNumber("AFM-20260922-1234"))
                .thenReturn(Optional.of(order));
        when(cartService.currentUser()).thenReturn(admin);

        OrderResponse response = orderService.byOrderNumber("AFM-20260922-1234");

        assertThat(response.orderNumber()).isEqualTo("AFM-20260922-1234");
    }

    @Test
    void byOrderNumber_unknownNumber_throws404() {
        when(orderRepository.findByOrderNumber("AFM-00000000-0000"))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> orderService.byOrderNumber("AFM-00000000-0000"))
                .isInstanceOf(ResourceNotFoundException.class);
    }
}

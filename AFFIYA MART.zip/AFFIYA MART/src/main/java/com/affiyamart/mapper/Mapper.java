package com.affiyamart.mapper;

import com.affiyamart.dto.*;
import com.affiyamart.entity.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Converts entities -> DTOs so JSON never contains lazy/cyclic references.
 */
public final class Mapper {

    private Mapper() {}

    public static ProductResponse toProductResponse(Product p) {
        if (p == null) return null;
        return new ProductResponse(
                p.getId(), p.getName(), p.getBrand(), p.getPrice(), p.getRating(),
                p.getStock(), p.getImageUrl(), p.getDescription(), p.getFeatured(),
                p.getCategory() != null ? p.getCategory().getId() : null,
                p.getCategory() != null ? p.getCategory().getName() : null
        );
    }

    public static List<ProductResponse> toProductList(List<Product> products) {
        return products.stream().map(Mapper::toProductResponse).collect(Collectors.toList());
    }

    public static CategoryResponse toCategoryResponse(Category c, long productCount) {
        if (c == null) return null;
        return new CategoryResponse(c.getId(), c.getName(), c.getDescription(),
                c.getImageUrl(), productCount);
    }

    public static UserResponse toUserResponse(User u) {
        if (u == null) return null;
        return new UserResponse(u.getId(), u.getName(), u.getEmail(), u.getPhone(),
                u.getRole(), u.getCreatedAt() != null ? u.getCreatedAt().toString() : null);
    }

    public static CartItemResponse toCartItemResponse(CartItem item) {
        Product p = item.getProduct();
        return new CartItemResponse(
                item.getId(),
                p.getId(),
                p.getName(),
                p.getBrand(),
                p.getImageUrl(),
                p.getPrice(),
                p.getStock(),
                item.getQuantity(),
                p.getPrice().multiply(java.math.BigDecimal.valueOf(item.getQuantity())),
                p.getCategory() != null ? p.getCategory().getName() : null
        );
    }

    public static OrderResponse toOrderResponse(Order o) {
        List<OrderItemResponse> items = o.getItems().stream()
                .map(i -> new OrderItemResponse(
                        i.getId(),
                        i.getProduct() != null ? i.getProduct().getId() : null,
                        i.getProductName(), i.getProductImage(), i.getPrice(),
                        i.getQuantity(), i.getSubtotal()))
                .collect(Collectors.toList());

        return new OrderResponse(
                o.getId(), o.getOrderNumber(), o.getCustomerName(), o.getPhone(),
                o.getEmail(), o.getAddress(), o.getCity(), o.getPincode(),
                o.getTotalAmount(), o.getStatus(), o.getOrderDate(), items);
    }

    public static List<OrderResponse> toOrderList(List<Order> orders) {
        return orders.stream().map(Mapper::toOrderResponse).collect(Collectors.toList());
    }
}

package com.affiyamart.service;

import com.affiyamart.dto.*;
import com.affiyamart.entity.CartItem;
import com.affiyamart.entity.Product;
import com.affiyamart.entity.User;
import com.affiyamart.exception.ApiException;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.mapper.Mapper;
import com.affiyamart.repository.CartItemRepository;
import com.affiyamart.repository.ProductRepository;
import com.affiyamart.repository.UserRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/** Shopping cart operations for the logged-in user. */
@Service
public class CartService {

    private final CartItemRepository cartItemRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public CartService(CartItemRepository cartItemRepository,
                       ProductRepository productRepository,
                       UserRepository userRepository) {
        this.cartItemRepository = cartItemRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    /** READ the whole cart with subtotals and total. */
    public CartResponse getCart() {
        User user = currentUser();
        List<CartItem> items = cartItemRepository.findByUser(user);

        List<CartItemResponse> lines = items.stream()
                .map(Mapper::toCartItemResponse)
                .collect(Collectors.toList());

        BigDecimal total = lines.stream()
                .map(CartItemResponse::subtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return new CartResponse(lines, total, lines.size());
    }

    /** CREATE - add a product (or increase it if already in the cart). */
    @Transactional
    public CartResponse add(CartItemRequest request) {
        User user = currentUser();
        Product product = productRepository.findById(request.productId())
                .orElseThrow(() -> new ResourceNotFoundException("Product", request.productId()));

        if (product.getStock() == null || product.getStock() < request.quantity()) {
            throw new ApiException("Only " + product.getStock() + " in stock for " + product.getName());
        }

        CartItem item = cartItemRepository
                .findByUserAndProductId(user, product.getId())
                .orElseGet(() -> new CartItem(user, product, 0));

        int newQty = item.getQuantity() + request.quantity();
        if (newQty > product.getStock()) {
            throw new ApiException("Only " + product.getStock() + " in stock for " + product.getName());
        }
        item.setQuantity(newQty);
        cartItemRepository.save(item);
        return getCart();
    }

    /** UPDATE quantity (0 removes the line). */
    @Transactional
    public CartResponse updateQuantity(Long itemId, UpdateCartRequest request) {
        User user = currentUser();
        CartItem item = cartItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart item", itemId));

        if (!item.getUser().getId().equals(user.getId())) {
            throw new ApiException("This cart item does not belong to you");
        }

        int qty = request.quantity();
        if (qty <= 0) {
            cartItemRepository.delete(item);
        } else {
            if (item.getProduct().getStock() < qty) {
                throw new ApiException("Only " + item.getProduct().getStock()
                        + " in stock for " + item.getProduct().getName());
            }
            item.setQuantity(qty);
            cartItemRepository.save(item);
        }
        return getCart();
    }

    /** DELETE one line. */
    @Transactional
    public CartResponse remove(Long itemId) {
        User user = currentUser();
        CartItem item = cartItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart item", itemId));
        if (!item.getUser().getId().equals(user.getId())) {
            throw new ApiException("This cart item does not belong to you");
        }
        cartItemRepository.delete(item);
        return getCart();
    }

    /** DELETE everything (called after checkout). */
    @Transactional
    public void clear(User user) {
        cartItemRepository.deleteByUser(user);
    }

    public int count() {
        return (int) cartItemRepository.countByUser(currentUser());
    }

    // ---------- helpers ----------

    public User currentUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ApiException("Authenticated user not found"));
    }
}

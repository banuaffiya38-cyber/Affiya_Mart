package com.affiyamart.service;

import com.affiyamart.dto.CategoryRequest;
import com.affiyamart.dto.CategoryResponse;
import com.affiyamart.exception.ApiException;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.mapper.Mapper;
import com.affiyamart.entity.Category;
import com.affiyamart.repository.CategoryRepository;
import com.affiyamart.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/** Full CRUD for chocolate categories (Milk, Dark, White, Wafer, Gift). */
@Service
public class CategoryService {

    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;

    public CategoryService(CategoryRepository categoryRepository,
                           ProductRepository productRepository) {
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
    }

    // READ (list)
    public List<CategoryResponse> findAll() {
        return categoryRepository.findAll().stream()
                .map(c -> Mapper.toCategoryResponse(
                        c, productRepository.countByCategoryId(c.getId())))
                .collect(Collectors.toList());
    }

    // READ (single)
    public CategoryResponse findById(Long id) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", id));
        return Mapper.toCategoryResponse(
                category, productRepository.countByCategoryId(category.getId()));
    }

    // CREATE
    @Transactional
    public CategoryResponse create(CategoryRequest request) {
        if (categoryRepository.existsByNameIgnoreCase(request.name().trim())) {
            throw new ApiException("Category already exists: " + request.name());
        }
        Category category = new Category(
                request.name().trim(), request.description(), request.imageUrl());
        return Mapper.toCategoryResponse(categoryRepository.save(category), 0);
    }

    // UPDATE
    @Transactional
    public CategoryResponse update(Long id, CategoryRequest request) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", id));
        category.setName(request.name().trim());
        category.setDescription(request.description());
        category.setImageUrl(request.imageUrl());
        Category saved = categoryRepository.save(category);
        return Mapper.toCategoryResponse(
                saved, productRepository.countByCategoryId(saved.getId()));
    }

    // DELETE
    @Transactional
    public void delete(Long id) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", id));
        if (productRepository.countByCategoryId(id) > 0) {
            throw new ApiException("Cannot delete: products still use this category");
        }
        categoryRepository.delete(category);
    }
}

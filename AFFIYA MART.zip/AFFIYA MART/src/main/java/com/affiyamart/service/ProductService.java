package com.affiyamart.service;

import com.affiyamart.dto.ProductRequest;
import com.affiyamart.dto.ProductResponse;
import com.affiyamart.entity.Category;
import com.affiyamart.entity.Product;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.mapper.Mapper;
import com.affiyamart.repository.CategoryRepository;
import com.affiyamart.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Full CRUD for products + search / category filter / brand filter / price sorting.
 */
@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public ProductService(ProductRepository productRepository,
                          CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    /**
     * READ (list) with optional filters.
     * @param search   keyword matched against name/brand (may be blank)
     * @param categoryId filter by category id (may be null)
     * @param brand    filter by brand (may be blank)
     * @param sort     price-asc | price-desc | rating | name (default: featured first)
     */
    public List<ProductResponse> search(String search, Long categoryId,
                                        String brand, String sort) {

        String keyword = (search == null || search.isBlank()) ? null : search.trim();
        String brandFilter = (brand == null || brand.isBlank()) ? null : brand.trim();

        List<Product> products = productRepository.search(keyword, categoryId, brandFilter);

        Comparator<Product> comparator;
        switch (sort == null ? "" : sort.toLowerCase()) {
            case "price-asc":
                comparator = Comparator.comparing(Product::getPrice);
                break;
            case "price-desc":
                comparator = Comparator.comparing(Product::getPrice).reversed();
                break;
            case "rating":
                comparator = Comparator.comparing(Product::getRating).reversed();
                break;
            case "name":
                comparator = Comparator.comparing(Product::getName,
                        String.CASE_INSENSITIVE_ORDER);
                break;
            default:
                comparator = Comparator
                        .comparing(Product::getFeatured, Comparator.reverseOrder())
                        .thenComparing(Product::getRating, Comparator.reverseOrder());
        }

        products = new ArrayList<>(products);
        products.sort(comparator);
        return Mapper.toProductList(products);
    }

    // READ (single)
    public ProductResponse findById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product", id));
        return Mapper.toProductResponse(product);
    }

    public List<ProductResponse> featured() {
        return Mapper.toProductList(productRepository.findByFeaturedTrue());
    }

    public List<String> brands() {
        return productRepository.findAllBrands();
    }

    // CREATE
    @Transactional
    public ProductResponse create(ProductRequest request) {
        Product product = new Product();
        apply(product, request);
        return Mapper.toProductResponse(productRepository.save(product));
    }

    // UPDATE
    @Transactional
    public ProductResponse update(Long id, ProductRequest request) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product", id));
        apply(product, request);
        return Mapper.toProductResponse(productRepository.save(product));
    }

    // DELETE
    @Transactional
    public void delete(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product", id));
        productRepository.delete(product);
    }

    // ---------- helpers ----------

    private void apply(Product product, ProductRequest request) {
        product.setName(request.name().trim());
        product.setBrand(request.brand().trim());
        product.setPrice(request.price());
        product.setRating(request.rating());
        product.setStock(request.stock());
        product.setImageUrl(request.imageUrl());
        product.setDescription(request.description());
        product.setFeatured(Boolean.TRUE.equals(request.featured()));

        if (request.categoryId() != null) {
            Category category = categoryRepository.findById(request.categoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category",
                            request.categoryId()));
            product.setCategory(category);
        } else {
            product.setCategory(null);
        }
    }
}

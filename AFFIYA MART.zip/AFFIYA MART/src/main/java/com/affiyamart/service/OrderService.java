package com.affiyamart.service;

import com.affiyamart.dto.CartItemResponse;
import com.affiyamart.dto.CheckoutRequest;
import com.affiyamart.dto.CartResponse;
import com.affiyamart.dto.OrderResponse;
import com.affiyamart.entity.*;
import com.affiyamart.exception.ApiException;
import com.affiyamart.exception.ResourceNotFoundException;
import com.affiyamart.mapper.Mapper;
import com.affiyamart.repository.OrderRepository;
import com.affiyamart.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Checkout (creates the order + order items) and order history. */
@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final CartService cartService;

    public OrderService(OrderRepository orderRepository,
                        ProductRepository productRepository,
                        CartService cartService) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.cartService = cartService;
    }

    /**
     * Places the order:
     * validates the cart, snapshots items, decrements stock, calculates the
     * total, saves the order + order_items and empties the cart.
     */
    @Transactional
    public OrderResponse placeOrder(CheckoutRequest request) {

        CartResponse cart = cartService.getCart();
        if (cart.items().isEmpty()) {
            throw new ApiException("Your cart is empty - add chocolates first!");
        }

        User user = cartService.currentUser();

        Order order = new Order();
        order.setOrderNumber(generateOrderNumber());
        order.setCustomerName(request.customerName().trim());
        order.setPhone(request.phone().trim());
        order.setEmail(request.email().trim());
        order.setAddress(request.address().trim());
        order.setCity(request.city().trim());
        order.setPincode(request.pincode().trim());
        order.setStatus("PLACED");
        order.setOrderDate(LocalDateTime.now());
        order.setUser(user);

        BigDecimal total = BigDecimal.ZERO;

        for (CartItemResponse line : cart.items()) {
            Product product = productRepository.findById(line.productId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product", line.productId()));

            if (product.getStock() < line.quantity()) {
                throw new ApiException("Not enough stock for " + product.getName()
                        + " (available: " + product.getStock() + ")");
            }

            // reduce stock
            product.setStock(product.getStock() - line.quantity());
            productRepository.save(product);

            OrderItem item = new OrderItem(
                    product.getName(), product.getImageUrl(), product.getPrice(),
                    line.quantity(), product);
            order.addItem(item);

            total = total.add(product.getPrice()
                    .multiply(BigDecimal.valueOf(line.quantity())));
        }

        order.setTotalAmount(total);
        Order saved = orderRepository.save(order);

        cartService.clear(user);   // empty the cart after a successful order

        return Mapper.toOrderResponse(saved);
    }

    /** Order history for the logged-in customer. */
    public List<OrderResponse> myOrders() {
        User user = cartService.currentUser();
        return Mapper.toOrderList(orderRepository.findByUserOrderByOrderDateDesc(user));
    }

    /** All orders (admin view / debugging). */
    public List<OrderResponse> allOrders() {
        return Mapper.toOrderList(orderRepository.findAllByOrderByOrderDateDesc());
    }

    /** Single order by its human-readable id, e.g. AFM-20260922-4821. */
    public OrderResponse byOrderNumber(String orderNumber) {
        Order order = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Order", orderNumber));
        User user = cartService.currentUser();
        boolean owner = order.getUser() != null && order.getUser().getId().equals(user.getId());
        boolean admin = "ROLE_ADMIN".equals(user.getRole());
        if (!owner && !admin) {
            throw new ApiException("You cannot view this order",
                    org.springframework.http.HttpStatus.FORBIDDEN);
        }
        return Mapper.toOrderResponse(order);
    }

    /** AFM-yyyyMMdd-XXXX (random 4 digits). */
    private String generateOrderNumber() {
        String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int rand = ThreadLocalRandom.current().nextInt(1000, 9999);
        return "AFM-" + date + "-" + rand;
    }
}

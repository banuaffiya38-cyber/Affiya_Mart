package com.affiyamart.service;

import com.affiyamart.dto.*;
import com.affiyamart.entity.User;
import com.affiyamart.exception.ApiException;
import com.affiyamart.mapper.Mapper;
import com.affiyamart.repository.UserRepository;
import com.affiyamart.security.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;

/** Registration, login and forgot-password (BCrypt + JWT). */
@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       AuthenticationManager authenticationManager,
                       JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
    }

    /** Creates the user (password BCrypt-hashed) and returns a JWT immediately. */
    @Transactional
    public AuthResponse register(RegisterRequest request) {

        if (!request.password().equals(request.confirmPassword())) {
            throw new ApiException("Password and Confirm Password do not match");
        }
        if (userRepository.existsByEmail(request.email().trim().toLowerCase())) {
            throw new ApiException("An account with this email already exists",
                    HttpStatus.CONFLICT);
        }

        User user = new User(
                request.name().trim(),
                request.phone().trim(),
                request.email().trim().toLowerCase(),
                passwordEncoder.encode(request.password())
        );
        user.setRole("ROLE_USER");
        userRepository.save(user);

        return buildAuthResponse(user);
    }

    /** Verifies credentials against the BCrypt hash stored in MySQL. */
    public AuthResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.email().trim().toLowerCase(), request.password()));

        User user = userRepository.findByEmail(request.email().trim().toLowerCase())
                .orElseThrow(() -> new ApiException("Invalid email or password",
                        HttpStatus.UNAUTHORIZED));

        // keep the authenticated principal for anything downstream
        return buildAuthResponse(user, authentication);
    }

    /**
     * Demo forgot-password: generates a temporary password, stores its BCrypt
     * hash in MySQL and returns the temporary password (no SMTP required).
     */
    @Transactional
    public MessageResponse forgotPassword(ForgotPasswordRequest request) {
        String email = request.email().trim().toLowerCase();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ApiException("No account found for this email",
                        HttpStatus.NOT_FOUND));

        String tempPassword = generateTempPassword();
        user.setPassword(passwordEncoder.encode(tempPassword));
        userRepository.save(user);

        return new MessageResponse(
                "Password reset OK. Temporary password for " + email + ": " + tempPassword
                        + "  (use it on the Login page, then change it later.)");
    }

    /** Current profile from the JWT. */
    public UserResponse profile(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));
        return Mapper.toUserResponse(user);
    }

    // ---------- helpers ----------

    private AuthResponse buildAuthResponse(User user) {
        return buildAuthResponse(user, null);
    }

    private AuthResponse buildAuthResponse(User user, Authentication authentication) {
        String token = jwtUtil.generateToken(
                user.getEmail(), user.getName(), user.getRole(), user.getId());
        return new AuthResponse(token, user.getId(), user.getName(),
                user.getEmail(), user.getPhone(), user.getRole());
    }

    private String generateTempPassword() {
        final String chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789@#";
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(8);
        for (int i = 0; i < 8; i++) sb.append(chars.charAt(random.nextInt(chars.length())));
        return sb.toString();
    }
}

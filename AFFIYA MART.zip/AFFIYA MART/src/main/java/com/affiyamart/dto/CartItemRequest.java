package com.affiyamart.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

/** "Add to cart" payload. */
public record CartItemRequest(
        @NotNull(message = "Product id is required")
        Long productId,

        @NotNull(message = "Quantity is required")
        @Min(value = 1, message = "Quantity must be at least 1")
        Integer quantity
) {}

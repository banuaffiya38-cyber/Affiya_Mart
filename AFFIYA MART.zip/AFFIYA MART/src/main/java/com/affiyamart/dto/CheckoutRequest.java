package com.affiyamart.dto;

import jakarta.validation.constraints.*;

/** Checkout form: customer + delivery details. */
public record CheckoutRequest(
        @NotBlank(message = "Customer name is required")
        @Size(max = 100)
        String customerName,

        @NotBlank(message = "Phone is required")
        @Pattern(regexp = "^[0-9+\\-\\s]{7,20}$", message = "Enter a valid phone number")
        String phone,

        @NotBlank(message = "Email is required")
        @Email(message = "Enter a valid email address")
        String email,

        @NotBlank(message = "Address is required")
        @Size(max = 255)
        String address,

        @NotBlank(message = "City is required")
        @Size(max = 80)
        String city,

        @NotBlank(message = "Pincode is required")
        @Pattern(regexp = "^[0-9]{4,10}$", message = "Enter a valid pincode")
        String pincode
) {}

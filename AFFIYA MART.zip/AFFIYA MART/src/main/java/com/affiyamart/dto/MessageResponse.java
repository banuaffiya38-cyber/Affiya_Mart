package com.affiyamart.dto;

/** Simple { message } reply used by auth/forgot-password endpoints. */
public record MessageResponse(String message) {}

package com.affiyamart.dto;

import java.math.BigDecimal;

/** One line of a placed order. */
public record OrderItemResponse(
        Long id,
        Long productId,
        String productName,
        String productImage,
        BigDecimal price,
        Integer quantity,
        BigDecimal subtotal
) {}

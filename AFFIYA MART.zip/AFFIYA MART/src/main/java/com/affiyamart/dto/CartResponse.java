package com.affiyamart.dto;

import java.math.BigDecimal;
import java.util.List;

/** Whole cart with computed total. */
public record CartResponse(
        List<CartItemResponse> items,
        BigDecimal total,
        int count
) {}

package com.affiyamart.dto;

import java.math.BigDecimal;

/** One line of the shopping cart. */
public record CartItemResponse(
        Long id,
        Long productId,
        String name,
        String brand,
        String imageUrl,
        BigDecimal price,
        Integer stock,
        Integer quantity,
        BigDecimal subtotal,
        String categoryName
) {}

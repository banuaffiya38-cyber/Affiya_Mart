package com.affiyamart.dto;

import java.math.BigDecimal;

/** Product sent to the frontend (category flattened to avoid JSON cycles). */
public record ProductResponse(
        Long id,
        String name,
        String brand,
        BigDecimal price,
        Double rating,
        Integer stock,
        String imageUrl,
        String description,
        Boolean featured,
        Long categoryId,
        String categoryName
) {}

package com.affiyamart.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Create / update a category. */
public record CategoryRequest(
        @NotBlank(message = "Category name is required")
        @Size(max = 60)
        String name,

        @Size(max = 255)
        String description,

        String imageUrl
) {}

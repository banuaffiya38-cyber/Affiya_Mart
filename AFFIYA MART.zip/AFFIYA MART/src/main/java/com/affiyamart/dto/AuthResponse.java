package com.affiyamart.dto;

/** Response returned after a successful login/registration. */
public record AuthResponse(
        String token,
        Long id,
        String name,
        String email,
        String phone,
        String role
) {}

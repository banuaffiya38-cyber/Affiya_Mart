package com.affiyamart.dto;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;

/** Create / update a product (full CRUD). */
public record ProductRequest(
        @NotBlank(message = "Product name is required")
        @Size(max = 120)
        String name,

        @NotBlank(message = "Brand is required")
        @Size(max = 60)
        String brand,

        @NotNull(message = "Price is required")
        @DecimalMin(value = "0.01", message = "Price must be greater than 0")
        BigDecimal price,

        @NotNull(message = "Rating is required")
        @DecimalMin(value = "0", message = "Rating must be 0 or more")
        @DecimalMax(value = "5", message = "Rating cannot exceed 5")
        Double rating,

        @NotNull(message = "Stock is required")
        @Min(value = 0, message = "Stock cannot be negative")
        Integer stock,

        String imageUrl,
        String description,

        Boolean featured,

        Long categoryId
) {}

package com.affiyamart.dto;

/** Category sent to the frontend. */
public record CategoryResponse(
        Long id,
        String name,
        String description,
        String imageUrl,
        long productCount
) {}

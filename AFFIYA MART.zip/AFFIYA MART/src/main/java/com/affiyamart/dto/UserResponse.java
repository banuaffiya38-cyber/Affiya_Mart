package com.affiyamart.dto;

/** Public user profile (My Account). */
public record UserResponse(
        Long id,
        String name,
        String email,
        String phone,
        String role,
        String createdAt
) {}

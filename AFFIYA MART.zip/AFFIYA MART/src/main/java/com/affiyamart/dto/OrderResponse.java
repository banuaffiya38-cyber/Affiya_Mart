package com.affiyamart.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/** Order + its items, used for confirmation and order history. */
public record OrderResponse(
        Long id,
        String orderNumber,
        String customerName,
        String phone,
        String email,
        String address,
        String city,
        String pincode,
        BigDecimal totalAmount,
        String status,
        LocalDateTime orderDate,
        List<OrderItemResponse> items
) {}

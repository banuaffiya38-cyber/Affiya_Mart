package com.affiyamart.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Keeps Spring Boot's /error endpoint JSON-only so the frontend always
 * receives a structured error instead of a white page.
 */
@RestController
public class JsonErrorController implements ErrorController {

    @RequestMapping("/error")
    public ResponseEntity<Map<String, Object>> handleError(HttpServletRequest request) {
        Integer status = (Integer) request.getAttribute(
                "jakarta.servlet.error.status_code");
        HttpStatus httpStatus = status != null
                ? HttpStatus.resolve(status)
                : HttpStatus.INTERNAL_SERVER_ERROR;

        return ResponseEntity.status(httpStatus).body(Map.of(
                "timestamp", LocalDateTime.now().toString(),
                "status", httpStatus.value(),
                "error", httpStatus.getReasonPhrase(),
                "message", "Resource not found or request failed"
        ));
    }
}

package com.affiyamart.exception;

import org.springframework.http.HttpStatus;

/** Thrown when an id does not exist -> mapped to HTTP 404. */
public class ResourceNotFoundException extends ApiException {

    public ResourceNotFoundException(String resource, Object id) {
        super(resource + " not found with id: " + id, HttpStatus.NOT_FOUND);
    }
}

package com.affiyamart.repository;

import com.affiyamart.entity.CartItem;
import com.affiyamart.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    List<CartItem> findByUser(User user);
    Optional<CartItem> findByUserAndProductId(User user, Long productId);
    long countByUser(User user);

    @Transactional
    void deleteByUser(User user);
}

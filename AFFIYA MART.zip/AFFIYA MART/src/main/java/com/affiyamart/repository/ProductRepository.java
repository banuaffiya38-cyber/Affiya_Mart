package com.affiyamart.repository;

import com.affiyamart.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByFeaturedTrue();

    List<Product> findByCategoryId(Long categoryId);

    List<Product> findByBrandIgnoreCase(String brand);

    List<Product> findAllByOrderByPriceAsc();
    List<Product> findAllByOrderByPriceDesc();
    List<Product> findAllByOrderByRatingDesc();

    /**
     * Search + optional filters (category / brand / keyword) in one query.
     * Passing null skips that filter.
     */
    @Query("""
           SELECT p FROM Product p
           WHERE (:search IS NULL
                  OR LOWER(p.name) LIKE LOWER(CONCAT('%', :search, '%'))
                  OR LOWER(p.brand) LIKE LOWER(CONCAT('%', :search, '%')))
             AND (:categoryId IS NULL OR p.category.id = :categoryId)
             AND (:brand IS NULL OR LOWER(p.brand) = LOWER(:brand))
           """)
    List<Product> search(@Param("search") String search,
                         @Param("categoryId") Long categoryId,
                         @Param("brand") String brand);

    @Query("SELECT DISTINCT p.brand FROM Product p ORDER BY p.brand")
    List<String> findAllBrands();

    long countByCategoryId(Long categoryId);
}

package com.affiyamart.config;

import com.affiyamart.entity.Category;
import com.affiyamart.entity.Product;
import com.affiyamart.entity.User;
import com.affiyamart.repository.CategoryRepository;
import com.affiyamart.repository.ProductRepository;
import com.affiyamart.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Seeds the database on first start:
 *  - 5 categories (Milk, Dark, White, Wafer, Gift)
 *  - 15 chocolate products (Dairy Milk, KitKat, Milkybar, 5 Star, Munch,
 *    Perk, Snickers, Ferrero Rocher, ...)
 *  - an admin and a demo customer (BCrypt hashed passwords)
 *
 * Everything only runs when the tables are empty, so database.sql and this
 * seeder never conflict.
 */
@Configuration
public class DataSeeder {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    @Bean
    CommandLineRunner seed(CategoryRepository categoryRepository,
                           ProductRepository productRepository,
                           UserRepository userRepository,
                           PasswordEncoder passwordEncoder) {
        return args -> seedIfEmpty(categoryRepository, productRepository,
                                   userRepository, passwordEncoder);
    }

    @Transactional
    void seedIfEmpty(CategoryRepository categoryRepository,
                     ProductRepository productRepository,
                     UserRepository userRepository,
                     PasswordEncoder passwordEncoder) {

        // ---------- categories ----------
        if (categoryRepository.count() == 0) {
            categoryRepository.save(new Category("Milk",  "Creamy milk chocolates loved by everyone", "images/cat-milk.svg"));
            categoryRepository.save(new Category("Dark",  "Rich, intense cocoa for true chocolate lovers", "images/cat-dark.svg"));
            categoryRepository.save(new Category("White", "Smooth vanilla-white chocolate treats", "images/cat-white.svg"));
            categoryRepository.save(new Category("Wafer", "Crunchy wafer bars with chocolate coating", "images/cat-wafer.svg"));
            categoryRepository.save(new Category("Gift",  "Beautifully packed chocolates for gifting", "images/cat-gift.svg"));
            log.info("Seeded 5 categories");
        }

        // ---------- products ----------
        if (productRepository.count() == 0) {
            Map<String, Category> cat = new HashMap<>();
            categoryRepository.findAll().forEach(c -> cat.put(c.getName(), c));

            record Seed(String name, String brand, String price, double rating,
                        int stock, String img, String desc, boolean featured, String cat) {}

            Seed[] seeds = {
                new Seed("Dairy Milk Silk",      "Cadbury",  "90.00",  4.8, 120, "images/dairymilk.svg",   "Silky smooth Cadbury dairy milk chocolate that melts in your mouth.", true,  "Milk"),
                new Seed("Dairy Milk",           "Cadbury",  "40.00",  4.7, 200, "images/dairymilk.svg",   "The classic Cadbury Dairy Milk with extra smooth taste.",             true,  "Milk"),
                new Seed("KitKat",               "Nestle",   "40.00",  4.6, 180, "images/kitkat.svg",      "Crispy wafer fingers covered with delicious milk chocolate.",         true,  "Wafer"),
                new Seed("Milkybar",             "Nestle",   "30.00",  4.5, 150, "images/milkybar.svg",    "Mild and creamy white chocolate bar for kids and adults.",            true,  "White"),
                new Seed("5 Star",               "Cadbury",  "40.00",  4.6, 160, "images/fivestar.svg",    "Chewy caramel and nougat wrapped in chocolate.",                      true,  "Milk"),
                new Seed("Munch",                "Nestle",   "40.00",  4.4, 170, "images/munch.svg",       "Crunchy wafer with a thick chocolate layer.",                         true,  "Wafer"),
                new Seed("Perk",                 "Cadbury",  "40.00",  4.3, 140, "images/perk.svg",        "Light, crisp wafer treat with chocolate.",                            false, "Wafer"),
                new Seed("Snickers",             "Mars",     "50.00",  4.7, 130, "images/snickers.svg",    "Peanuts, caramel and nougat dipped in milk chocolate.",              true,  "Milk"),
                new Seed("Ferrero Rocher",       "Ferrero", "350.00",  4.9,  60, "images/ferrero.svg",     "Golden wrapped hazelnut chocolates - the king of gifting.",          true,  "Gift"),
                new Seed("Bournville 50% Cocoa", "Cadbury", "120.00",  4.6,  90, "images/bournville.svg",  "Intense dark chocolate with 50% rich cocoa.",                         true,  "Dark"),
                new Seed("Amul Dark 55%",        "Amul",    "100.00",  4.5, 100, "images/dark.svg",        "Deep dark chocolate with a smooth finish.",                          false, "Dark"),
                new Seed("Lindt Excellence 70%", "Lindt",   "250.00",  4.8,  70, "images/dark.svg",        "Premium Swiss dark chocolate with 70% cocoa.",                       false, "Dark"),
                new Seed("Cadbury Celebrations", "Cadbury", "300.00",  4.7,  80, "images/gift.svg",        "Assorted chocolate gift pack for every celebration.",                 true,  "Gift"),
                new Seed("Toblerone Milk",       "Toblerone","280.00", 4.6,  55, "images/gift.svg",        "Swiss triangular chocolate with honey and almond nougat.",           false, "Gift"),
                new Seed("Nestle KitKat Chunky", "Nestle",   "60.00",  4.4, 110, "images/kitkat.svg",      "Thick wafer bar loaded with extra chocolate.",                        false, "Wafer"),
            };

            for (Seed s : seeds) {
                productRepository.save(new Product(
                        s.name(), s.brand(), new BigDecimal(s.price()), s.rating(),
                        s.stock(), s.img(), s.desc(), s.featured(), cat.get(s.cat())));
            }
            log.info("Seeded {} products", seeds.length);
        }

        // ---------- users ----------
        if (userRepository.findByEmail("admin@affiyamart.com").isEmpty()) {
            User admin = new User("AFFIYA Admin", "9000000000", "admin@affiyamart.com",
                    passwordEncoder.encode("admin123"));
            admin.setRole("ROLE_ADMIN");
            userRepository.save(admin);
            log.info("Seeded admin user  -> admin@affiyamart.com / admin123");
        }

        if (userRepository.findByEmail("user@affiyamart.com").isEmpty()) {
            User demo = new User("Demo Customer", "9111111111", "user@affiyamart.com",
                    passwordEncoder.encode("user123"));
            demo.setRole("ROLE_USER");
            userRepository.save(demo);
            log.info("Seeded demo user   -> user@affiyamart.com / user123");
        }
    }
}

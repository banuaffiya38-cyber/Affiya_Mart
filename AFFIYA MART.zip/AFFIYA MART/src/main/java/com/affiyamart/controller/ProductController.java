package com.affiyamart.controller;

import com.affiyamart.dto.ProductRequest;
import com.affiyamart.dto.ProductResponse;
import com.affiyamart.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

/**
 * /api/products  -  full CRUD
 *   GET    /api/products?search=&categoryId=&brand=&sort=   (public)
 *   GET    /api/products/featured                           (public)
 *   GET    /api/products/brands                             (public)
 *   GET    /api/products/{id}                               (public)
 *   POST   /api/products                                    (ADMIN)
 *   PUT    /api/products/{id}                               (ADMIN)
 *   DELETE /api/products/{id}                               (ADMIN)
 */
@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    /** READ list + search/filter/sort (uses fetch() on the Products page). */
    @GetMapping
    public ResponseEntity<List<ProductResponse>> list(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false, defaultValue = "featured") String sort) {
        return ResponseEntity.ok(productService.search(search, categoryId, brand, sort));
    }

    /** Featured products for the Home page. */
    @GetMapping("/featured")
    public ResponseEntity<List<ProductResponse>> featured() {
        return ResponseEntity.ok(productService.featured());
    }

    /** Distinct brand list for the brand filter dropdown. */
    @GetMapping("/brands")
    public ResponseEntity<List<String>> brands() {
        return ResponseEntity.ok(productService.brands());
    }

    /** READ single. */
    @GetMapping("/{id}")
    public ResponseEntity<ProductResponse> get(@PathVariable Long id) {
        return ResponseEntity.ok(productService.findById(id));
    }

    /** CREATE (admin). */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ProductResponse> create(@Valid @RequestBody ProductRequest request) {
        ProductResponse created = productService.create(request);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(created.id()).toUri();
        return ResponseEntity.created(location).body(created);
    }

    /** UPDATE (admin). */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ProductResponse> update(@PathVariable Long id,
                                                  @Valid @RequestBody ProductRequest request) {
        return ResponseEntity.ok(productService.update(id, request));
    }

    /** DELETE (admin). */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        productService.delete(id);
        return ResponseEntity.noContent().build();
    }
}

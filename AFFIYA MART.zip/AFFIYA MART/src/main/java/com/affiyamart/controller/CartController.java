package com.affiyamart.controller;

import com.affiyamart.dto.CartItemRequest;
import com.affiyamart.dto.CartResponse;
import com.affiyamart.dto.UpdateCartRequest;
import com.affiyamart.service.CartService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * /api/cart  -  requires a valid JWT (the cart belongs to the logged-in user)
 *   GET    /api/cart          read cart + total
 *   POST   /api/cart          add a product (body: {productId, quantity})
 *   PUT    /api/cart/{id}     change quantity (body: {quantity}) - 0 removes
 *   DELETE /api/cart/{id}     remove one line
 *   DELETE /api/cart          empty the cart
 */
@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping
    public ResponseEntity<CartResponse> get() {
        return ResponseEntity.ok(cartService.getCart());
    }

    @PostMapping
    public ResponseEntity<CartResponse> add(@Valid @RequestBody CartItemRequest request) {
        return ResponseEntity.ok(cartService.add(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CartResponse> update(@PathVariable Long id,
                                               @Valid @RequestBody UpdateCartRequest request) {
        return ResponseEntity.ok(cartService.updateQuantity(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<CartResponse> remove(@PathVariable Long id) {
        return ResponseEntity.ok(cartService.remove(id));
    }

    @DeleteMapping
    public ResponseEntity<Void> clear() {
        cartService.clear(cartService.currentUser());
        return ResponseEntity.noContent().build();
    }
}

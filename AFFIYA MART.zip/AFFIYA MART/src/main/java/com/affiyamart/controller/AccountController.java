package com.affiyamart.controller;

import com.affiyamart.dto.CartResponse;
import com.affiyamart.dto.UserResponse;
import com.affiyamart.mapper.Mapper;
import com.affiyamart.service.CartService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

/**
 * /api/account  -  My Account page (JWT required)
 */
@RestController
@RequestMapping("/api/account")
public class AccountController {

    private final CartService cartService;

    public AccountController(CartService cartService) {
        this.cartService = cartService;
    }

    /** Profile of the logged-in user. */
    @GetMapping
    public ResponseEntity<UserResponse> profile(@AuthenticationPrincipal UserDetails principal) {
        if (principal == null) {
            return ResponseEntity.status(401).build();
        }
        return ResponseEntity.ok(Mapper.toUserResponse(cartService.currentUser()));
    }

    /** Current cart contents - used for the navbar badge. */
    @GetMapping("/cart-count")
    public ResponseEntity<CartResponse> cartCount() {
        return ResponseEntity.ok(cartService.getCart());
    }
}

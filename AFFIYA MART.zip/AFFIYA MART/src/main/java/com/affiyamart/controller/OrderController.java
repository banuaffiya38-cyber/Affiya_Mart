package com.affiyamart.controller;

import com.affiyamart.dto.CheckoutRequest;
import com.affiyamart.dto.OrderResponse;
import com.affiyamart.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * /api/orders  -  checkout + order history (JWT required)
 *   POST /api/orders                place an order from the current cart
 *   GET  /api/orders                my order history
 *   GET  /api/orders/all            every order (ADMIN)
 *   GET  /api/orders/{orderNumber}  one order
 */
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    /** CREATE - checkout. Returns the new Order ID. */
    @PostMapping
    public ResponseEntity<OrderResponse> placeOrder(
            @Valid @RequestBody CheckoutRequest request) {
        return ResponseEntity.ok(orderService.placeOrder(request));
    }

    /** READ - order history of the logged-in customer. */
    @GetMapping
    public ResponseEntity<List<OrderResponse>> myOrders() {
        return ResponseEntity.ok(orderService.myOrders());
    }

    /** READ - all orders (admin). */
    @GetMapping("/all")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<OrderResponse>> allOrders() {
        return ResponseEntity.ok(orderService.allOrders());
    }

    /** READ - single order by order number. */
    @GetMapping("/{orderNumber}")
    public ResponseEntity<OrderResponse> byNumber(@PathVariable String orderNumber) {
        return ResponseEntity.ok(orderService.byOrderNumber(orderNumber));
    }
}

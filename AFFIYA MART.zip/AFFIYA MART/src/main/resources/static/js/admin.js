/* ============================================================
   AFFIYA MART - Admin (full CRUD wired to the UI)
   GET    /api/products        list   -> renders the table
   POST   /api/products        create -> refreshes the table
   PUT    /api/products/{id}   update -> refreshes the table
   DELETE /api/products/{id}   delete -> refreshes the table
   ============================================================ */

let modal = null;

document.addEventListener('DOMContentLoaded', () => {

  /* only ROLE_ADMIN may use this page */
  if (!Session.isAdmin) {
    document.getElementById('adminArea').classList.add('d-none');
    document.getElementById('adminGuard').classList.remove('d-none');
    return;
  }

  modal = new bootstrap.Modal(document.getElementById('productModal'));
  loadProducts();
  loadCategories();
});

/* ---------- READ ---------- */
async function loadProducts() {
  const body = document.getElementById('adminBody');
  body.innerHTML = '<tr><td colspan="9" class="text-center py-4">' +
    '<div class="spinner-border spinner-choco"></div></td></tr>';

  try {
    const products = await apiFetch('/api/products?sort=name');
    document.getElementById('adminCount').textContent = products.length;

    if (!products.length) {
      body.innerHTML = '<tr><td colspan="9" class="text-center py-4 text-muted">' +
        'No products yet - click "Add Product".'</td></tr>';
      return;
    }

    body.innerHTML = products.map(p => `
      <tr>
        <td>${imgTag(p.imageUrl, p.name)}</td>
        <td class="fw-semibold">${escapeHtml(p.name)}</td>
        <td>${escapeHtml(p.brand)}</td>
        <td><span class="badge badge-cat">${escapeHtml(p.categoryName || '-')}</span></td>
        <td class="text-end">${money(p.price)}</td>
        <td class="text-center"><span class="rating">${stars(p.rating)}</span></td>
        <td class="text-center">${stockBadge(p.stock)}</td>
        <td class="text-center">${p.featured ? '⭐' : '-'}</td>
        <td class="text-end text-nowrap">
          <button class="btn btn-sm btn-outline-choco me-1"
                  onclick='openEdit(${JSON.stringify(p)})' title="Edit">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger"
                  onclick="deleteProduct(${p.id}, '${escapeHtml(p.name)}')" title="Delete">
            <i class="bi bi-trash"></i>
          </button>
        </td>
      </tr>`).join('');

  } catch (err) {
    body.innerHTML = `<tr><td colspan="9" class="text-center py-4 text-danger">
      ${escapeHtml(err.message)}</td></tr>`;
  }
}

async function loadCategories() {
  try {
    const categories = await apiFetch('/api/categories');
    document.getElementById('pCategory').innerHTML =
      '<option value="">-- no category --</option>' +
      categories.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
  } catch { /* categories stay empty */ }
}

/* ---------- CREATE ---------- */
function openCreate() {
  document.getElementById('modalTitle').textContent = 'Add Product';
  document.getElementById('productForm').reset();
  document.getElementById('productId').value = '';
}

/* ---------- UPDATE ---------- */
function openEdit(p) {
  document.getElementById('modalTitle').textContent = 'Edit Product';
  document.getElementById('productId').value = p.id;
  document.getElementById('pName').value = p.name;
  document.getElementById('pBrand').value = p.brand;
  document.getElementById('pPrice').value = p.price;
  document.getElementById('pRating').value = p.rating;
  document.getElementById('pStock').value = p.stock;
  document.getElementById('pImage').value = p.imageUrl || '';
  document.getElementById('pDescription').value = p.description || '';
  document.getElementById('pFeatured').checked = !!p.featured;
  const sel = document.getElementById('pCategory');
  if (p.categoryId) sel.value = String(p.categoryId);
  modal.show();
}

/* create OR update depending on whether an id is present */
async function saveProduct() {
  const id = document.getElementById('productId').value;

  const payload = {
    name:        document.getElementById('pName').value.trim(),
    brand:       document.getElementById('pBrand').value.trim(),
    price:       parseFloat(document.getElementById('pPrice').value),
    rating:      parseFloat(document.getElementById('pRating').value),
    stock:       parseInt(document.getElementById('pStock').value, 10),
    imageUrl:    document.getElementById('pImage').value.trim() || 'images/choc-default.svg',
    description: document.getElementById('pDescription').value.trim(),
    featured:    document.getElementById('pFeatured').checked,
    categoryId:  document.getElementById('pCategory').value
                   ? Number(document.getElementById('pCategory').value) : null
  };

  if (!payload.name || !payload.brand || isNaN(payload.price)) {
    notify('Name, brand and price are required.', false);
    return;
  }

  const btn = document.getElementById('saveBtn');
  btn.disabled = true;

  try {
    if (id) {
      await apiFetch('/api/products/' + id, { method: 'PUT', body: JSON.stringify(payload) });
      notify('Product updated - MySQL row refreshed ✔');
    } else {
      await apiFetch('/api/products', { method: 'POST', body: JSON.stringify(payload) });
      notify('Product created - MySQL row added ✔');
    }
    modal.hide();
    loadProducts();          // re-fetch so the table always matches the DB
  } catch (err) {
    notify(err.message || 'Save failed. (Are you logged in as admin?)', false);
  } finally {
    btn.disabled = false;
  }
}

/* ---------- DELETE ---------- */
async function deleteProduct(id, name) {
  if (!confirm('Delete "' + name + '" from the database?')) return;
  try {
    await apiFetch('/api/products/' + id, { method: 'DELETE' });
    notify('Product deleted ✔');
    loadProducts();          // refresh the displayed data
  } catch (err) {
    notify(err.message || 'Delete failed.', false);
  }
}

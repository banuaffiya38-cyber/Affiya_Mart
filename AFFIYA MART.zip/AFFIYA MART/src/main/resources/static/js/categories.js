/* ============================================================
   AFFIYA MART - Categories page
   GET /api/categories  -> Milk, Dark, White, Wafer, Gift cards
   Clicking a card opens the Products page filtered by that id.
   ============================================================ */
document.addEventListener('DOMContentLoaded', async () => {
  showLoading('categoryGrid');

  const blurbs = {
    Milk:  'Creamy, mellow and everyone\'s childhood favourite.',
    Dark:  'Bold cocoa for the serious chocolate connoisseur.',
    White: 'Silky vanilla-white indulgence.',
    Wafer: 'Crunchy layers wrapped in smooth chocolate.',
    Gift:  'Beautifully packed boxes for every celebration.'
  };

  try {
    const categories = await apiFetch('/api/categories');

    document.getElementById('categoryGrid').innerHTML = categories.map(c => `
      <div class="col-6 col-md-4 col-xl">
        <a href="products.html?category=${c.id}" class="cat-card d-block text-dark h-100">
          ${imgTag(c.imageUrl, c.name)}
          <h5>${escapeHtml(c.name)}</h5>
          <p class="small text-muted mb-2">${escapeHtml(c.description || blurbs[c.name] || '')}</p>
          <span class="badge badge-cat">${c.productCount} product${c.productCount === 1 ? '' : 's'}</span>
          <div class="mt-3"><span class="btn btn-choco btn-sm w-100">Explore</span></div>
        </a>
      </div>`).join('');
  } catch (err) {
    showError('categoryGrid', 'Could not load categories: ' + err.message);
  }
});

/* ============================================================
   AFFIYA MART - Products page
   - product search using fetch()          -> GET /api/products?search=
   - category filter                        -> GET /api/products?categoryId=
   - brand filter                           -> GET /api/products?brand=
   - price / rating / name sorting          -> GET /api/products?sort=
   All filters are combined into ONE fetch call.
   ============================================================ */

let searchTimer = null;

document.addEventListener('DOMContentLoaded', async () => {

  /* pre-select category if the URL contains ?category=4 */
  const urlCategory = new URLSearchParams(location.search).get('category');

  /* ---------- populate filter dropdowns ---------- */
  try {
    const categories = await apiFetch('/api/categories');
    const catSelect = document.getElementById('categoryFilter');
    catSelect.innerHTML = '<option value="">All Categories</option>' +
      categories.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
    if (urlCategory) catSelect.value = urlCategory;
  } catch { /* leave default option */ }

  try {
    const brands = await apiFetch('/api/products/brands');
    const brandSelect = document.getElementById('brandFilter');
    brandSelect.innerHTML = '<option value="">All Brands</option>' +
      brands.map(b => `<option value="${escapeHtml(b)}">${escapeHtml(b)}</option>`).join('');
  } catch { /* leave default option */ }

  /* ---------- listeners ---------- */
  document.getElementById('searchInput')
    .addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(loadProducts, 320);   // debounce the fetch
    });

  ['categoryFilter', 'brandFilter', 'sortSelect'].forEach(id =>
    document.getElementById(id).addEventListener('change', loadProducts));

  await loadProducts();
});

/* single fetch() that carries every filter + sort option */
async function loadProducts() {
  const grid = document.getElementById('productGrid');
  showLoading('productGrid');

  const search    = document.getElementById('searchInput').value.trim();
  const categoryId = document.getElementById('categoryFilter').value;
  const brand     = document.getElementById('brandFilter').value;
  const sort      = document.getElementById('sortSelect').value;

  const params = new URLSearchParams();
  if (search)     params.set('search', search);
  if (categoryId) params.set('categoryId', categoryId);
  if (brand)      params.set('brand', brand);
  if (sort)       params.set('sort', sort);

  try {
    const products = await apiFetch('/api/products?' + params.toString());

    document.getElementById('resultCount').textContent =
      products.length + ' product' + (products.length === 1 ? '' : 's') + ' found';

    grid.innerHTML = products.length
      ? products.map(productCard).join('')
      : `<div class="col-12"><div class="empty-state">
           <img src="images/choc-default.svg" alt="">
           <p class="mb-2">No chocolates match your search.</p>
           <button class="btn btn-choco btn-sm" onclick="resetFilters()">Clear filters</button>
         </div></div>`;
  } catch (err) {
    showError('productGrid', 'Could not load products: ' + err.message);
  }
}

function resetFilters() {
  document.getElementById('searchInput').value = '';
  document.getElementById('categoryFilter').value = '';
  document.getElementById('brandFilter').value = '';
  document.getElementById('sortSelect').value = 'featured';
  loadProducts();
}

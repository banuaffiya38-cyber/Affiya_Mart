/* ============================================================
   AFFIYA MART - Product Details page
   GET /api/products/{id}
   - quantity stepper
   - Add to Cart        -> POST /api/cart
   - Buy Now            -> add to cart, then go to Checkout
   ============================================================ */

let currentProduct = null;

document.addEventListener('DOMContentLoaded', async () => {
  const id = new URLSearchParams(location.search).get('id');
  const area = document.getElementById('detailArea');

  if (!id) {
    area.innerHTML = '<div class="empty-state"><p>No product selected.</p></div>';
    return;
  }

  try {
    currentProduct = await apiFetch('/api/products/' + id);
    render(currentProduct);
  } catch (err) {
    area.innerHTML = `<div class="empty-state">
        <img src="images/choc-default.svg" alt="">
        <p>${escapeHtml(err.message)}</p>
        <a href="products.html" class="btn btn-choco btn-sm">Back to Products</a>
      </div>`;
  }
});

function render(p) {
  document.getElementById('crumbName').textContent = p.name;
  document.title = p.name + ' | AFFIYA MART';

  const inStock = p.stock > 0;

  document.getElementById('detailArea').innerHTML = `
    <div class="row g-4 align-items-start">
      <div class="col-md-5">
        ${imgTag(p.imageUrl, p.name, 'detail-img')}
      </div>

      <div class="col-md-7">
        <span class="brand text-uppercase small" style="color:var(--cocoa-600)">
          ${escapeHtml(p.brand)}
        </span>
        <h2 class="mt-1 mb-2" style="color:var(--cocoa-800)">${escapeHtml(p.name)}</h2>

        <div class="rating mb-2 fs-5">${stars(p.rating)}
          <span class="count"> ${Number(p.rating).toFixed(1)} / 5</span>
        </div>

        <div class="mb-3 d-flex flex-wrap gap-2 align-items-center">
          <span class="badge badge-cat">${escapeHtml(p.categoryName || 'Chocolate')}</span>
          ${stockBadge(p.stock)}
        </div>

        <div class="display-6 mb-3" style="color:var(--berry)">${money(p.price)}</div>

        <p class="text-muted" style="line-height:1.7">
          ${escapeHtml(p.description || 'Delicious chocolate from AFFIYA MART.')}
        </p>

        <div class="d-flex align-items-center gap-3 flex-wrap mb-4">
          <span class="fw-semibold">Quantity</span>
          <div class="qty-box">
            <button type="button" onclick="changeQty(-1)" aria-label="decrease">−</button>
            <input type="text" id="qty" value="1" readonly aria-label="quantity">
            <button type="button" onclick="changeQty(1)" aria-label="increase">+</button>
          </div>
          <small class="text-muted">${p.stock} available</small>
        </div>

        <div class="d-flex flex-wrap gap-3">
          <button class="btn btn-choco btn-lg px-4" id="addBtn"
                  onclick="addThis()" ${inStock ? '' : 'disabled'}>
            <i class="bi bi-cart-plus me-2"></i>Add to Cart
          </button>
          <button class="btn btn-gold btn-lg px-4" id="buyBtn"
                  onclick="buyNow()" ${inStock ? '' : 'disabled'}>
            <i class="bi bi-lightning-charge me-2"></i>Buy Now
          </button>
        </div>

        <div class="row g-3 mt-4">
          <div class="col-sm-4"><div class="p-3 rounded-3" style="background:var(--white-choc)">
            <i class="bi bi-truck me-1" style="color:var(--cocoa-600)"></i>
            <span class="small">Free delivery above ₹499</span></div></div>
          <div class="col-sm-4"><div class="p-3 rounded-3" style="background:var(--white-choc)">
            <i class="bi bi-shield-check me-1" style="color:var(--cocoa-600)"></i>
            <span class="small">100% genuine product</span></div></div>
          <div class="col-sm-4"><div class="p-3 rounded-3" style="background:var(--white-choc)">
            <i class="bi bi-arrow-counterclockwise me-1" style="color:var(--cocoa-600)"></i>
            <span class="small">7-day easy returns</span></div></div>
        </div>
      </div>
    </div>`;
}

function currentQty() {
  return parseInt(document.getElementById('qty').value, 10) || 1;
}

function changeQty(delta) {
  const input = document.getElementById('qty');
  const max = currentProduct ? currentProduct.stock : 99;
  let value = currentQty() + delta;
  if (value < 1) value = 1;
  if (value > max) { value = max; notify('Only ' + max + ' in stock', false); }
  input.value = value;
}

async function addThis() {
  try {
    const cart = await apiFetch('/api/cart', {
      method: 'POST',
      body: JSON.stringify({ productId: currentProduct.id, quantity: currentQty() })
    });
    const badge = document.getElementById('cartCount');
    if (badge) badge.textContent = cart.items.length;
    notify(currentQty() + ' x ' + currentProduct.name + ' added to cart 🍫');
  } catch (err) {
    notify(err.message, false);
  }
}

async function buyNow() {
  await addThis();
  location.href = 'checkout.html';
}

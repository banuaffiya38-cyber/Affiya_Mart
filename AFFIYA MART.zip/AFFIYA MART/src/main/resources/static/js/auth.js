/* ============================================================
   AFFIYA MART - Login page logic
   - login form -> POST /api/auth/login -> redirect to Home
   - show / hide password
   - forgot password modal -> POST /api/auth/forgot-password
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {

  const params = new URLSearchParams(location.search);
  if (params.get('registered') === '1') notify('Account created! Please log in.');

  /* ---------------- LOGIN ---------------- */
  const form = document.getElementById('loginForm');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      clearErrors(form);

      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const btn = document.getElementById('loginBtn');

      if (!email || !password) {
        setFieldError('email', !email ? 'Email is required' : null);
        setFieldError('password', !password ? 'Password is required' : null);
        return;
      }

      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Signing in...';
      try {
        const auth = await apiFetch('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email, password })
        });
        Session.save(auth);                       // store JWT + profile
        location.href = 'home.html';              // redirect to Home after login
      } catch (err) {
        notify(err.message || 'Login failed. Please try again.', false);
        btn.disabled = false;
        btn.innerHTML = 'Login';
      }
    });
  }

  /* ---------------- FORGOT PASSWORD ---------------- */
  const forgotForm = document.getElementById('forgotForm');
  if (forgotForm) {
    forgotForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('forgotEmail').value.trim();
      const out = document.getElementById('forgotResult');
      out.classList.add('d-none');
      if (!email) return;
      try {
        const res = await apiFetch('/api/auth/forgot-password', {
          method: 'POST',
          body: JSON.stringify({ email })
        });
        out.textContent = res.message;
        out.className = 'alert alert-success';
      } catch (err) {
        out.textContent = err.message;
        out.className = 'alert alert-danger';
      }
    });
  }
});

/* small inline-error helpers */
function setFieldError(id, message) {
  const el = document.getElementById(id + 'Error');
  if (!el) return;
  el.textContent = message || '';
  el.style.display = message ? 'block' : 'none';
}
function clearErrors(scope) {
  scope.querySelectorAll('.field-error').forEach(el => {
    el.textContent = ''; el.style.display = 'none';
  });
}

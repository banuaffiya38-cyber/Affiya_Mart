/* ============================================================
   AFFIYA MART - shared frontend helpers
   - session storage (JWT + user)
   - fetch() wrapper with automatic Authorization header
   - responsive navbar injection
   - auth guard, formatting helpers, toast messages
   ============================================================ */

/* The app is served BY Spring Boot, so "" = same origin.
   Auto-detects Live Server / file:// and points at the API instead. */
const API_BASE = (location.port === '5500' || location.protocol === 'file:')
  ? 'http://localhost:8080' : '';

/* ---------------- session ---------------- */
const Session = {
  get token()  { return localStorage.getItem('am_token'); },
  get user()   { try { return JSON.parse(localStorage.getItem('am_user')) || null; } catch { return null; } },
  save(auth) {
    localStorage.setItem('am_token', auth.token);
    localStorage.setItem('am_user', JSON.stringify({
      id: auth.id, name: auth.name, email: auth.email,
      phone: auth.phone, role: auth.role
    }));
  },
  clear() { localStorage.removeItem('am_token'); localStorage.removeItem('am_user'); },
  get isLoggedIn() { return !!Session.token; },
  get isAdmin() { const u = Session.user; return !!u && u.role === 'ROLE_ADMIN'; }
};

/* ---------------- fetch wrapper ---------------- */
async function apiFetch(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.body && !(options.headers && options.headers['Content-Type'])) {
    headers['Content-Type'] = 'application/json';
  }
  if (Session.token) headers['Authorization'] = 'Bearer ' + Session.token;

  const res = await fetch(API_BASE + path, { ...options, headers });

  if (res.status === 401) {           // expired / invalid token
    Session.clear();
    if (!location.pathname.endsWith('index.html') && location.pathname !== '/') {
      location.href = 'index.html?expired=1';
      return;
    }
  }
  if (res.status === 204) return null;

  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const msg = (data && (data.message || data.error)) || ('Request failed (' + res.status + ')');
    const err = new Error(msg);
    err.status = res.status;
    err.fields = data && data.errors;
    throw err;
  }
  return data;
}

/* ---------------- auth guard ---------------- */
function requireAuth() {
  if (!Session.isLoggedIn) {
    location.href = 'index.html';
    return false;
  }
  return true;
}

/* redirect an already-logged-in visitor to Home */
function redirectIfLoggedIn() {
  if (Session.isLoggedIn) { location.href = 'home.html'; return true; }
  return false;
}

/* ---------------- navbar ---------------- */
function renderNavbar() {
  const host = document.getElementById('navbar');
  if (!host) return;

  const page = document.body.dataset.page || '';
  const loggedIn = Session.isLoggedIn;
  const isAdmin = Session.isAdmin;
  const name = loggedIn && Session.user ? Session.user.name.split(' ')[0] : '';

  const link = (id, href, label) =>
    `<li class="nav-item"><a class="nav-link ${page === id ? 'active' : ''}" href="${href}">${label}</a></li>`;

  host.innerHTML = `
  <nav class="navbar navbar-expand-lg navbar-dark affiya-navbar sticky-top">
    <div class="container">
      <a class="navbar-brand" href="${loggedIn ? 'home.html' : 'index.html'}">
        <img src="images/logo.svg" alt="AFFIYA MART logo">
        <span>
          <span class="brand-text">AFFIYA MART</span>
          <small class="brand-tag">Sweet Moments. Happy Hearts. Easy Shopping.</small>
        </span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain"
              aria-controls="navMain" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navMain">
        ${loggedIn ? `
        <ul class="navbar-nav ms-auto align-items-lg-center">
          ${link('home', 'home.html', 'Home')}
          ${link('products', 'products.html', 'Products')}
          ${link('categories', 'categories.html', 'Categories')}
          <li class="nav-item position-relative">
            <a class="nav-link ${page === 'cart' ? 'active' : ''}" href="cart.html">
              Cart <span class="cart-badge" id="cartCount">0</span>
            </a>
          </li>
          ${isAdmin ? link('admin', 'admin.html', 'Admin') : ''}
          ${link('account', 'account.html', 'My Account')}
          <li class="nav-item ms-lg-2">
            <button class="btn btn-sm btn-gold" onclick="logout()">Logout</button>
          </li>
        </ul>` : `
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="index.html">Login</a></li>
          <li class="nav-item"><a class="nav-link" href="register.html">Register</a></li>
        </ul>`}
      </div>
    </div>
  </nav>`;

  if (loggedIn) refreshCartBadge();
}

async function refreshCartBadge() {
  const el = document.getElementById('cartCount');
  if (!el) return;
  try {
    const cart = await apiFetch('/api/account/cart-count');
    el.textContent = cart.items ? cart.items.length : 0;
  } catch { /* ignore - badge simply stays as is */ }
}

function logout() {
  Session.clear();
  location.href = 'index.html?logout=1';
}

/* ---------------- UI helpers ---------------- */
const money = n => '₹' + Number(n || 0).toFixed(2);

function stars(rating) {
  const r = Math.round(Number(rating) || 0);
  let out = '';
  for (let i = 1; i <= 5; i++) out += i <= r ? '★' : '☆';
  return out;
}

function stockBadge(stock) {
  const s = Number(stock);
  if (s <= 0)   return '<span class="badge badge-stock-out">Out of stock</span>';
  if (s <= 20)  return '<span class="badge badge-stock-low">Only ' + s + ' left</span>';
  return '<span class="badge badge-stock-in">In stock: ' + s + '</span>';
}

function imgTag(src, alt, cls) {
  const url = src || 'images/choc-default.svg';
  return `<img src="${url}" alt="${escapeHtml(alt || '')}" class="${cls || ''}"
           onerror="this.onerror=null;this.src='images/choc-default.svg'">`;
}

function escapeHtml(str) {
  return String(str == null ? '' : str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* pretty alert used across pages */
function notify(message, ok = true) {
  const el = document.getElementById('liveToast');
  if (el) {
    el.querySelector('.toast-body').textContent = message;
    el.classList.toggle('text-bg-success', ok);
    el.classList.toggle('text-bg-danger', !ok);
    new bootstrap.Toast(el, { delay: 3200 }).show();
    return;
  }
  alert(message);
}

function showLoading(id) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = '<div class="empty-state"><div class="spinner-border spinner-choco" role="status"></div><p class="mt-3">Loading chocolates...</p></div>';
}

function showError(id, message) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = `<div class="empty-state"><img src="images/choc-default.svg" alt=""><p>${escapeHtml(message)}</p></div>`;
}

/* password show / hide (used by login + register) */
function togglePassword(inputId, iconId) {
  const input = document.getElementById(inputId);
  const icon  = document.getElementById(iconId);
  if (!input) return;
  const showing = input.type === 'text';
  input.type = showing ? 'password' : 'text';
  if (icon) icon.className = showing ? 'bi bi-eye' : 'bi bi-eye-slash';
}

/* boot: navbar + guard run on every page that includes api.js */
document.addEventListener('DOMContentLoaded', () => {
  const mode = document.body.dataset.auth;      // "required" | "guest" | undefined
  if (mode === 'required' && !requireAuth()) return;
  if (mode === 'guest' && redirectIfLoggedIn()) return;
  renderNavbar();
  const params = new URLSearchParams(location.search);
  if (params.get('logout') === '1')  notify('You have been logged out. See you soon!');
  if (params.get('expired') === '1') notify('Your session expired. Please log in again.', false);
});

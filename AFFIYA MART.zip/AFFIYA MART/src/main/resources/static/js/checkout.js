/* ============================================================
   AFFIYA MART - Checkout page
   - loads the cart for the order summary (GET /api/cart)
   - validates customer + delivery details
   - POST /api/orders  -> shows the generated Order ID
   ============================================================ */

const FREE_DELIVERY_ABOVE = 499;
const DELIVERY_FEE = 40;

let cartSnapshot = null;

document.addEventListener('DOMContentLoaded', async () => {

  /* pre-fill name/email/phone from the stored profile */
  const user = Session.user;
  if (user) {
    setVal('customerName', user.name);
    setVal('email', user.email);
    setVal('phone', user.phone);
  }

  try {
    cartSnapshot = await apiFetch('/api/cart');
    renderSummary(cartSnapshot);
  } catch (err) {
    document.getElementById('summaryItems').innerHTML =
      '<div class="empty-state py-3">' + escapeHtml(err.message) + '</div>';
  }

  document.getElementById('checkoutForm').addEventListener('submit', placeOrder);
});

function setVal(id, value) {
  const el = document.getElementById(id);
  if (el && value) el.value = value;
}

function renderSummary(cart) {
  const items = cart.items || [];

  if (!items.length) {
    document.getElementById('summaryItems').innerHTML =
      `<div class="empty-state py-3">
         <p class="mb-2">Your cart is empty.</p>
         <a href="products.html" class="btn btn-choco btn-sm">Add chocolates</a>
       </div>`;
    document.getElementById('placeBtn').disabled = true;
    return;
  }

  document.getElementById('summaryItems').innerHTML = items.map(i => `
    <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
      <div class="d-flex align-items-center gap-2">
        ${imgTag(i.imageUrl, i.name)}
        <div>
          <div class="small fw-semibold">${escapeHtml(i.name)}</div>
          <small class="text-muted">${i.quantity} x ${money(i.price)}</small>
        </div>
      </div>
      <div class="fw-bold">${money(i.subtotal)}</div>
    </div>`).join('');

  const subtotal = Number(cart.total);
  const delivery = subtotal >= FREE_DELIVERY_ABOVE ? 0 : DELIVERY_FEE;

  document.getElementById('ckSubtotal').textContent = money(subtotal);
  document.getElementById('ckDelivery').textContent = delivery === 0 ? 'FREE' : money(delivery);
  document.getElementById('ckTotal').textContent = money(subtotal + delivery);
}

async function placeOrder(e) {
  e.preventDefault();
  clearErrors(e.target);

  const payload = {
    customerName: document.getElementById('customerName').value.trim(),
    phone:        document.getElementById('phone').value.trim(),
    email:        document.getElementById('email').value.trim(),
    address:      document.getElementById('address').value.trim(),
    city:         document.getElementById('city').value.trim(),
    pincode:      document.getElementById('pincode').value.trim()
  };

  /* client-side validation */
  let valid = true;
  if (payload.customerName.length < 2) { setFieldError('customerName', 'Name is required'); valid = false; }
  if (!/^[0-9+\-\s]{7,20}$/.test(payload.phone)) { setFieldError('phone', 'Enter a valid phone'); valid = false; }
  if (!/^\S+@\S+\.\S+$/.test(payload.email))     { setFieldError('email', 'Enter a valid email'); valid = false; }
  if (payload.address.length < 5)  { setFieldError('address', 'Enter your full address'); valid = false; }
  if (!payload.city)               { setFieldError('city', 'City is required'); valid = false; }
  if (!/^[0-9]{4,10}$/.test(payload.pincode))    { setFieldError('pincode', 'Enter a valid pincode'); valid = false; }
  if (!valid) { notify('Please fix the highlighted fields.', false); return; }

  const btn = document.getElementById('placeBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Placing order...';

  try {
    const order = await apiFetch('/api/orders', {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    /* ---- show the Order ID ---- */
    document.getElementById('successOrderId').textContent = order.orderNumber;
    document.getElementById('successTotal').textContent = money(order.totalAmount);
    document.getElementById('checkoutArea').classList.add('d-none');
    document.getElementById('successArea').classList.remove('d-none');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    refreshCartBadge();

  } catch (err) {
    notify(err.message || 'Could not place the order.', false);
    if (err.fields) Object.entries(err.fields).forEach(([f, m]) => setFieldError(f, m));
    btn.disabled = false;
    btn.innerHTML = '<i class="bi bi-bag-check me-2"></i>Place Order';
  }
}

function setFieldError(id, message) {
  const el = document.getElementById(id + 'Error');
  if (!el) return;
  el.textContent = message || '';
  el.style.display = message ? 'block' : 'none';
}
function clearErrors(scope) {
  scope.querySelectorAll('.field-error').forEach(el => {
    el.textContent = ''; el.style.display = 'none';
  });
}

/* ============================================================
   AFFIYA MART - My Account page
   GET /api/auth/me      -> profile card
   GET /api/orders       -> order history (status, total, items)
   ============================================================ */
document.addEventListener('DOMContentLoaded', async () => {

  /* ---------- profile ---------- */
  try {
    const me = await apiFetch('/api/auth/me');
    document.getElementById('profileName').textContent = me.name;
    document.getElementById('profileEmail').textContent = me.email;
    document.getElementById('profilePhone').textContent = me.phone || '-';
    document.getElementById('profileJoined').textContent =
      me.createdAt ? me.createdAt.substring(0, 10) : '-';
    document.getElementById('profileRole').textContent =
      me.role === 'ROLE_ADMIN' ? 'Administrator' : 'Valued Customer';
    document.getElementById('avatar').textContent =
      (me.name || '?').trim().charAt(0).toUpperCase();
  } catch (err) {
    notify('Could not load profile: ' + err.message, false);
  }

  /* ---------- order history ---------- */
  const area = document.getElementById('ordersArea');
  try {
    const orders = await apiFetch('/api/orders');
    document.getElementById('orderCount').textContent =
      orders.length + ' order' + (orders.length === 1 ? '' : 's');

    if (!orders.length) {
      area.innerHTML = `<div class="empty-state py-4">
          <img src="images/choc-default.svg" alt="">
          <p class="mb-3">You haven't placed any orders yet.</p>
          <a href="products.html" class="btn btn-choco btn-sm">Start Shopping</a>
        </div>`;
      return;
    }

    area.innerHTML = orders.map(o => `
      <div class="border rounded-3 p-3 mb-3">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
          <div>
            <div class="fw-bold" style="color:var(--berry)">${escapeHtml(o.orderNumber)}</div>
            <small class="text-muted">
              ${o.orderDate ? o.orderDate.replace('T', ' ').substring(0, 16) : ''}
            </small>
          </div>
          <div class="text-end">
            <span class="badge ${o.status === 'PLACED' ? 'badge-stock-low' : 'badge-stock-in'} me-2">
              ${escapeHtml(o.status)}
            </span>
            <span class="fw-bold">${money(o.totalAmount)}</span>
          </div>
        </div>

        <div class="small text-muted mt-2">
          <i class="bi bi-geo-alt me-1"></i>${escapeHtml(o.address)}, ${escapeHtml(o.city)} -
          ${escapeHtml(o.pincode)} &nbsp;|&nbsp;
          <i class="bi bi-telephone me-1"></i>${escapeHtml(o.phone)}
        </div>

        <div class="mt-2 d-flex flex-wrap gap-2">
          ${(o.items || []).map(i => `
            <span class="badge" style="background:var(--white-choc);color:var(--cocoa-700)">
              ${escapeHtml(i.productName)} x ${i.quantity}
            </span>`).join('')}
        </div>
      </div>`).join('');

  } catch (err) {
    area.innerHTML = `<div class="empty-state py-4">
        <p>Could not load orders: ${escapeHtml(err.message)}</p></div>`;
  }
});

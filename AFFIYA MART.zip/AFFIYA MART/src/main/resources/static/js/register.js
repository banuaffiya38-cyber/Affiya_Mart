/* ============================================================
   AFFIYA MART - Registration page logic
   - name / phone / email / password / confirm password
   - live confirm-password + password-strength validation
   - POST /api/auth/register -> store JWT -> redirect Home
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {

  const form = document.getElementById('registerForm');
  if (!form) return;

  const pwd  = document.getElementById('password');
  const conf = document.getElementById('confirmPassword');

  /* live password strength */
  pwd.addEventListener('input', () => {
    const v = pwd.value;
    let score = 0;
    if (v.length >= 6) score++;
    if (v.length >= 10) score++;
    if (/[A-Z]/.test(v) && /[a-z]/.test(v)) score++;
    if (/[0-9]/.test(v)) score++;
    if (/[^A-Za-z0-9]/.test(v)) score++;

    const labels = ['', 'Weak', 'Fair', 'Good', 'Strong', 'Very strong'];
    const colors = ['', '#a3372b', '#d4a017', '#7aa64b', '#187a4b', '#187a4b'];
    const el = document.getElementById('pwdStrength');
    if (!v) { el.textContent = ''; return; }
    el.textContent = 'Strength: ' + labels[score];
    el.style.color = colors[score];
  });

  /* live confirm-password validation */
  conf.addEventListener('input', () => validateMatch());
  conf.addEventListener('blur',  () => validateMatch());

  function validateMatch() {
    const ok = pwd.value === conf.value;
    setFieldError('confirmPassword',
      conf.value && !ok ? 'Passwords do not match' : null);
    return ok;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(form);

    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = pwd.value;
    const confirmPassword = conf.value;
    let valid = true;

    if (name.length < 2)      { setFieldError('name', 'Enter your full name (min 2 chars)'); valid = false; }
    if (!/^[0-9+\-\s]{7,20}$/.test(phone)) { setFieldError('phone', 'Enter a valid phone number'); valid = false; }
    if (!/^\S+@\S+\.\S+$/.test(email))     { setFieldError('email', 'Enter a valid email address'); valid = false; }
    if (password.length < 6)  { setFieldError('password', 'Password must be at least 6 characters'); valid = false; }
    if (confirmPassword !== password || !confirmPassword) {
      setFieldError('confirmPassword', 'Passwords do not match'); valid = false;
    }
    if (!valid) return;

    const btn = document.getElementById('registerBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Creating account...';

    try {
      const auth = await apiFetch('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({ name, phone, email, password, confirmPassword })
      });
      Session.save(auth);
      location.href = 'home.html';
    } catch (err) {
      notify(err.message || 'Registration failed.', false);
      if (err.fields) {
        Object.entries(err.fields).forEach(([field, msg]) => setFieldError(field, msg));
      }
      btn.disabled = false;
      btn.innerHTML = 'Create Account';
    }
  });
});

function setFieldError(id, message) {
  const el = document.getElementById(id + 'Error');
  if (!el) return;
  el.textContent = message || '';
  el.style.display = message ? 'block' : 'none';
}
function clearErrors(scope) {
  scope.querySelectorAll('.field-error').forEach(el => {
    el.textContent = ''; el.style.display = 'none';
  });
}

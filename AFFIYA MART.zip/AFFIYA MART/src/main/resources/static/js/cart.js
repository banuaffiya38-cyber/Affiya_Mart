/* ============================================================
   AFFIYA MART - Shopping Cart page
   GET    /api/cart           read
   PUT    /api/cart/{id}      increase / decrease quantity
   DELETE /api/cart/{id}      remove a line
   Subtotal per line + overall total are recalculated on every change.
   ============================================================ */

const FREE_DELIVERY_ABOVE = 499;
const DELIVERY_FEE = 40;

document.addEventListener('DOMContentLoaded', loadCart);

async function loadCart() {
  showLoading('cartArea');
  try {
    const cart = await apiFetch('/api/cart');
    renderCart(cart);
  } catch (err) {
    showError('cartArea', 'Could not load your cart: ' + err.message);
  }
}

function renderCart(cart) {
  const area = document.getElementById('cartArea');
  const items = cart.items || [];

  if (!items.length) {
    area.innerHTML = `<div class="empty-state">
        <img src="images/choc-default.svg" alt="">
        <h5>Your cart is empty</h5>
        <p class="mb-3">Let's fix that - chocolate is waiting!</p>
        <a href="products.html" class="btn btn-choco">Browse Chocolates</a>
      </div>`;
    updateSummary(0, 0);
    const btn = document.getElementById('checkoutBtn');
    btn.classList.add('disabled'); btn.setAttribute('aria-disabled', 'true');
    return;
  }

  area.innerHTML = `
    <div class="table-responsive">
      <table class="table table-cart bg-white rounded-3 shadow-sm">
        <thead style="background:var(--cocoa-800);color:var(--gold)">
          <tr>
            <th>Product</th><th class="text-end">Price</th>
            <th class="text-center" style="min-width:150px">Quantity</th>
            <th class="text-end">Subtotal</th><th></th>
          </tr>
        </thead>
        <tbody>
          ${items.map(i => `
            <tr>
              <td>
                <div class="d-flex align-items-center gap-2">
                  ${imgTag(i.imageUrl, i.name)}
                  <div>
                    <div class="fw-semibold">${escapeHtml(i.name)}</div>
                    <small class="text-muted">${escapeHtml(i.brand)}</small><br>
                    <span class="badge badge-cat badge-sm">${escapeHtml(i.categoryName || 'Chocolate')}</span>
                  </div>
                </div>
              </td>
              <td class="text-end">${money(i.price)}</td>
              <td>
                <div class="d-flex justify-content-center">
                  <div class="qty-box">
                    <button onclick="changeQty(${i.id}, ${i.quantity - 1}, ${i.stock})"
                            aria-label="decrease">−</button>
                    <input type="text" value="${i.quantity}" readonly aria-label="quantity">
                    <button onclick="changeQty(${i.id}, ${i.quantity + 1}, ${i.stock})"
                            aria-label="increase">+</button>
                  </div>
                </div>
                <div class="text-center small text-muted mt-1">max ${i.stock}</div>
              </td>
              <td class="text-end fw-bold">${money(i.subtotal)}</td>
              <td class="text-end">
                <button class="btn btn-sm btn-outline-danger rounded-circle"
                        onclick="removeItem(${i.id})" title="Remove">
                  <i class="bi bi-trash"></i>
                </button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;

  updateSummary(items.length, Number(cart.total));
  const btn = document.getElementById('checkoutBtn');
  btn.classList.remove('disabled'); btn.removeAttribute('aria-disabled');
}

/* recalculates subtotal + delivery + total */
function updateSummary(count, subtotal) {
  const delivery = (subtotal === 0 || subtotal >= FREE_DELIVERY_ABOVE) ? 0 : DELIVERY_FEE;
  document.getElementById('sumItems').textContent = count;
  document.getElementById('sumSubtotal').textContent = money(subtotal);
  document.getElementById('sumDelivery').textContent =
    delivery === 0 ? 'FREE' : money(delivery);
  document.getElementById('sumTotal').textContent = money(subtotal + delivery);
}

async function changeQty(itemId, newQty, stock) {
  if (newQty > stock) { notify('Only ' + stock + ' in stock', false); return; }
  if (newQty <= 0) { removeItem(itemId); return; }
  try {
    const cart = await apiFetch('/api/cart/' + itemId, {
      method: 'PUT',
      body: JSON.stringify({ quantity: newQty })
    });
    renderCart(cart);
    refreshCartBadge();
  } catch (err) {
    notify(err.message, false);
  }
}

async function removeItem(itemId) {
  try {
    const cart = await apiFetch('/api/cart/' + itemId, { method: 'DELETE' });
    renderCart(cart);
    refreshCartBadge();
    notify('Item removed from cart');
  } catch (err) {
    notify(err.message, false);
  }
}

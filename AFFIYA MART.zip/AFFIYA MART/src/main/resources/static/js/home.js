/* ============================================================
   AFFIYA MART - Home page
   - loads categories      -> GET /api/categories
   - loads featured items  -> GET /api/products/featured
   ============================================================ */

/* one reusable product card, shared by home + products pages */
function productCard(p) {
  return `
  <div class="col-6 col-md-4 col-xl-3">
    <div class="choco-card">
      ${imgTag(p.imageUrl, p.name, 'card-img-top')}
      <div class="card-body d-flex flex-column">
        <span class="brand">${escapeHtml(p.brand)}</span>
        <h6 class="mb-1 fw-bold">${escapeHtml(p.name)}</h6>
        <div class="rating mb-1">${stars(p.rating)}
          <span class="count">(${Number(p.rating).toFixed(1)})</span>
        </div>
        <div class="mb-2">
          <span class="badge badge-cat mb-1">${escapeHtml(p.categoryName || 'Chocolate')}</span>
          ${stockBadge(p.stock)}
        </div>
        <div class="price mb-3">${money(p.price)}</div>
        <div class="mt-auto d-flex gap-2">
          <button class="btn btn-choco btn-sm flex-fill"
                  onclick="addToCart(${p.id})" ${p.stock <= 0 ? 'disabled' : ''}>
            <i class="bi bi-cart-plus"></i> Add to Cart
          </button>
          <a href="product-details.html?id=${p.id}" class="btn btn-outline-choco btn-sm flex-fill">
            View Details
          </a>
        </div>
      </div>
    </div>
  </div>`;
}

async function addToCart(productId, quantity = 1) {
  try {
    const cart = await apiFetch('/api/cart', {
      method: 'POST',
      body: JSON.stringify({ productId, quantity })
    });
    const badge = document.getElementById('cartCount');
    if (badge) badge.textContent = cart.items.length;
    notify('Added to your cart! 🍫');
  } catch (err) {
    notify(err.message, false);
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  showLoading('featuredGrid');

  /* ---------- categories ---------- */
  try {
    const categories = await apiFetch('/api/categories');
    document.getElementById('categoryGrid').innerHTML = categories.map(c => `
      <div class="col-6 col-md-4 col-lg">
        <a href="products.html?category=${c.id}" class="cat-card d-block text-dark">
          ${imgTag(c.imageUrl, c.name)}
          <h5>${escapeHtml(c.name)}</h5>
          <div class="count">${c.productCount} product${c.productCount === 1 ? '' : 's'}</div>
        </a>
      </div>`).join('');
  } catch (err) {
    document.getElementById('categoryGrid').innerHTML =
      `<div class="col-12">${'<div class="empty-state">Categories unavailable: ' + escapeHtml(err.message) + '</div>'}</div>`;
  }

  /* ---------- featured products ---------- */
  try {
    const products = await apiFetch('/api/products/featured');
    document.getElementById('featuredGrid').innerHTML =
      products.length ? products.map(productCard).join('')
        : '<div class="col-12"><div class="empty-state">No featured products yet.</div></div>';
  } catch (err) {
    showError('featuredGrid', 'Could not load products: ' + err.message);
  }
});

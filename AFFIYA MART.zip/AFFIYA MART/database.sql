-- ============================================================
-- AFFIYA MART - Complete MySQL 8 Database Script
-- Database name: affiya_mart
-- Run:  mysql -u root < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS affiya_mart
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE affiya_mart;

-- ------------------------------------------------------------
-- 1) USERS
-- ------------------------------------------------------------
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart_items;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id          BIGINT       NOT NULL AUTO_INCREMENT,
  name        VARCHAR(100) NOT NULL,
  phone       VARCHAR(20)  NOT NULL,
  email       VARCHAR(150) NOT NULL,
  password    VARCHAR(255) NOT NULL,           -- BCrypt hash
  role        VARCHAR(20)  NOT NULL DEFAULT 'ROLE_USER',
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_users_email (email)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2) CATEGORIES  (Milk, Dark, White, Wafer, Gift)
-- ------------------------------------------------------------
CREATE TABLE categories (
  id          BIGINT       NOT NULL AUTO_INCREMENT,
  name        VARCHAR(60)  NOT NULL,
  description VARCHAR(255) NULL,
  image_url   VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_categories_name (name)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3) PRODUCTS
-- ------------------------------------------------------------
CREATE TABLE products (
  id          BIGINT        NOT NULL AUTO_INCREMENT,
  name        VARCHAR(120)  NOT NULL,
  brand       VARCHAR(60)   NOT NULL,
  price       DECIMAL(10,2) NOT NULL,
  rating      DOUBLE        NOT NULL DEFAULT 0,
  stock       INT           NOT NULL DEFAULT 0,
  image_url   VARCHAR(255)  NULL,
  description TEXT          NULL,
  featured    BIT(1)        NOT NULL DEFAULT b'0',
  category_id BIGINT        NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_products_category
    FOREIGN KEY (category_id) REFERENCES categories (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  KEY idx_products_brand (brand),
  KEY idx_products_price (price)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4) CART_ITEMS
-- ------------------------------------------------------------
CREATE TABLE cart_items (
  id         BIGINT NOT NULL AUTO_INCREMENT,
  quantity   INT    NOT NULL DEFAULT 1,
  user_id    BIGINT NOT NULL,
  product_id BIGINT NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_cart_user
    FOREIGN KEY (user_id)    REFERENCES users (id)    ON DELETE CASCADE,
  CONSTRAINT fk_cart_product
    FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE,
  UNIQUE KEY uk_cart_user_product (user_id, product_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5) ORDERS
-- ------------------------------------------------------------
CREATE TABLE orders (
  id            BIGINT        NOT NULL AUTO_INCREMENT,
  order_number  VARCHAR(30)   NOT NULL,
  customer_name VARCHAR(100)  NOT NULL,
  phone         VARCHAR(20)   NOT NULL,
  email         VARCHAR(150)  NOT NULL,
  address       VARCHAR(255)  NOT NULL,
  city          VARCHAR(80)   NOT NULL,
  pincode       VARCHAR(10)   NOT NULL,
  total_amount  DECIMAL(10,2) NOT NULL,
  status        VARCHAR(30)   NOT NULL DEFAULT 'PLACED',
  order_date    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  user_id       BIGINT        NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_orders_number (order_number),
  CONSTRAINT fk_orders_user
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6) ORDER_ITEMS
-- ------------------------------------------------------------
CREATE TABLE order_items (
  id            BIGINT        NOT NULL AUTO_INCREMENT,
  product_name  VARCHAR(120)  NOT NULL,
  product_image VARCHAR(255)  NULL,
  price         DECIMAL(10,2) NOT NULL,
  quantity      INT           NOT NULL,
  order_id      BIGINT        NOT NULL,
  product_id    BIGINT        NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_items_order
    FOREIGN KEY (order_id)   REFERENCES orders (id)    ON DELETE CASCADE,
  CONSTRAINT fk_items_product
    FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- SAMPLE DATA
-- Passwords below are BCrypt hashes:
--   admin123  ->  $2a$10$X0/VwPjRPrXjPqP8XoJ1bOaI9Jm3hV0mQbWnqLqCqJ7p5xYbqJq1e
-- (The DataSeeder class re-seeds everything automatically if the
--  tables are empty, so inserting users here is optional.)
-- ============================================================

INSERT INTO categories (name, description, image_url) VALUES
 ('Milk',  'Creamy milk chocolates loved by everyone',      'images/cat-milk.svg'),
 ('Dark',  'Rich, intense cocoa for true chocolate lovers', 'images/cat-dark.svg'),
 ('White', 'Smooth vanilla-white chocolate treats',         'images/cat-white.svg'),
 ('Wafer', 'Crunchy wafer bars with chocolate coating',     'images/cat-wafer.svg'),
 ('Gift',  'Beautifully packed chocolates for gifting',     'images/cat-gift.svg');

INSERT INTO products (name, brand, price, rating, stock, image_url, description, featured, category_id) VALUES
 ('Dairy Milk Silk',      'Cadbury',   90.00,  4.8, 120, 'images/dairymilk.svg', 'Silky smooth Cadbury dairy milk chocolate that melts in your mouth.',      1, 1),
 ('Dairy Milk',           'Cadbury',   40.00,  4.7, 200, 'images/dairymilk.svg', 'The classic Cadbury Dairy Milk with extra smooth taste.',                  1, 1),
 ('KitKat',               'Nestle',    40.00,  4.6, 180, 'images/kitkat.svg',    'Crispy wafer fingers covered with delicious milk chocolate.',              1, 4),
 ('Milkybar',             'Nestle',    30.00,  4.5, 150, 'images/milkybar.svg',  'Mild and creamy white chocolate bar for kids and adults.',                 1, 3),
 ('5 Star',               'Cadbury',   40.00,  4.6, 160, 'images/fivestar.svg',  'Chewy caramel and nougat wrapped in chocolate.',                           1, 1),
 ('Munch',                'Nestle',    40.00,  4.4, 170, 'images/munch.svg',     'Crunchy wafer with a thick chocolate layer.',                              1, 4),
 ('Perk',                 'Cadbury',   40.00,  4.3, 140, 'images/perk.svg',      'Light, crisp wafer treat with chocolate.',                                 0, 4),
 ('Snickers',             'Mars',      50.00,  4.7, 130, 'images/snickers.svg',  'Peanuts, caramel and nougat dipped in milk chocolate.',                   1, 1),
 ('Ferrero Rocher',       'Ferrero',  350.00,  4.9,  60, 'images/ferrero.svg',   'Golden wrapped hazelnut chocolates - the king of gifting.',               1, 5),
 ('Bournville 50% Cocoa', 'Cadbury',  120.00,  4.6,  90, 'images/bournville.svg','Intense dark chocolate with 50% rich cocoa.',                              1, 2),
 ('Amul Dark 55%',        'Amul',     100.00,  4.5, 100, 'images/dark.svg',      'Deep dark chocolate with a smooth finish.',                               0, 2),
 ('Lindt Excellence 70%', 'Lindt',    250.00,  4.8,  70, 'images/dark.svg',      'Premium Swiss dark chocolate with 70% cocoa.',                            0, 2),
 ('Cadbury Celebrations', 'Cadbury',  300.00,  4.7,  80, 'images/gift.svg',      'Assorted chocolate gift pack for every celebration.',                      1, 5),
 ('Toblerone Milk',       'Toblerone',280.00,  4.6,  55, 'images/gift.svg',      'Swiss triangular chocolate with honey and almond nougat.',                0, 5),
 ('Nestle KitKat Chunky', 'Nestle',    60.00,  4.4, 110, 'images/kitkat.svg',    'Thick wafer bar loaded with extra chocolate.',                             0, 4);

-- ============================================================
-- VERIFY
-- ============================================================
SELECT 'Categories' AS tbl, COUNT(*) AS rows_count FROM categories
UNION ALL
SELECT 'Products',  COUNT(*) FROM products
UNION ALL
SELECT 'Users',     COUNT(*) FROM users;

@echo off
setlocal
set "MYSQLDIR=C:\Program Files\MySQL\MySQL Server 8.0\bin"
set "INI=C:\ProgramData\MySQL\MySQL Server 8.0\my.ini"
set "PW=affiya@123"

echo ============================================
echo  AFFIYA MART - MySQL root password reset
echo  New password will be: %PW%
echo ============================================

net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: Not running as Administrator.
  echo Right-click this file -^> "Run as administrator"
  echo.
  pause
  exit /b 1
)

echo.
echo [1/6] Stopping MySQL80 service ...
net stop MySQL80
if errorlevel 1 (
  echo ERROR: could not stop the MySQL80 service.
  pause
  exit /b 1
)

echo [2/6] Cleaning up leftover mysqld processes ...
taskkill /IM mysqld.exe /F >nul 2>&1
timeout /t 3 /nobreak >nul

echo [3/6] Starting temporary MySQL without password checks ...
start "" /min "%MYSQLDIR%\mysqld.exe" --defaults-file="%INI%" --skip-grant-tables --shared-memory
timeout /t 10 /nobreak >nul

echo [4/6] Setting root password to %PW% ...
"%MYSQLDIR%\mysql.exe" -u root -e "FLUSH PRIVILEGES; ALTER USER 'root'@'localhost' IDENTIFIED BY '%PW%'; FLUSH PRIVILEGES;"
if errorlevel 1 (
  echo ERROR: could not alter the password. A small window titled
  echo "MySQL-TEMP" may show the reason - please tell me what it says.
  pause
  exit /b 1
)

echo [5/6] Stopping temporary MySQL ...
taskkill /IM mysqld.exe /F >nul 2>&1
timeout /t 3 /nobreak >nul

echo [6/6] Restarting MySQL80 service ...
net start MySQL80
if errorlevel 1 (
  echo ERROR: could not start the MySQL80 service.
  pause
  exit /b 1
)

echo.
echo Verifying login with the new password ...
"%MYSQLDIR%\mysql.exe" -u root -p%PW% -e "SELECT 'SUCCESS' AS result;" 2>nul
if errorlevel 1 (
  echo VERIFY FAILED - the password was not accepted.
  pause
  exit /b 1
)

echo.
echo ============================================
echo  DONE. root password is now: %PW%
echo  You can close this window.
echo ============================================
pause

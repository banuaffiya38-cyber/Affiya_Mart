# 🍫 AFFIYA MART

> **Sweet Moments. Happy Hearts. Easy Shopping.**

A full-stack **chocolate e-commerce platform** built with **Spring Boot 3 + MySQL 8** and a
vanilla HTML/CSS/JS frontend served straight from the backend. Includes JWT authentication,
product catalogue with search/filter/sort, shopping cart, checkout with stock management,
order history, and an admin panel.

---

## ✨ Features

| Area | What's included |
|------|-----------------|
| **Auth** | Register, login, forgot-password (temporary password), JWT (HS256), BCrypt hashing |
| **Catalogue** | 15 seeded chocolate products, 5 categories, search, category/brand filters, sorting (price ↑↓, rating, name, featured) |
| **Cart** | Add / update quantity / remove lines, stock validation, live totals & navbar count |
| **Checkout** | Order placement (`AFM-yyyyMMdd-XXXX` order numbers), stock decrement, cart clearing |
| **Orders** | Customer order history + admin view of all orders, ownership/role checks |
| **Admin** | Full product & category CRUD (ADMIN role only, enforced via `@PreAuthorize`) |
| **Frontend** | Login, register, home, categories, products, product details, cart, checkout, account, admin pages |
| **API quality** | Consistent JSON errors `{timestamp, status, error, message, errors?}`, bean-validation field errors, CORS enabled |

## 🛠 Tech Stack

- **Backend:** Java 17, Spring Boot 3.2.5 (Web, Data JPA, Security, Validation)
- **Database:** MySQL 8 (`affiya_mart`), Hibernate DDL `update` + optional `database.sql`
- **Auth:** JWT (`jjwt` 0.11.5), stateless security filter chain, BCrypt
- **Frontend:** HTML + CSS + vanilla JavaScript (no build step), served from `classpath:/static/`
- **Testing:** JUnit 5, Mockito, MockMvc (standalone) — no database required
- **Build:** Maven (wrapper included: `mvnw` / `mvnw.cmd`)

## 📁 Project Structure

```
AFFIYA MART/
├── database.sql                  # MySQL schema + sample data (optional, seeder covers it)
├── pom.xml
├── mvnw / mvnw.cmd / .mvn/       # Maven wrapper
├── requests.http                 # VS Code REST Client examples
├── curl-examples.sh              # curl examples
└── src/
    ├── main/java/com/affiyamart/
    │   ├── config/               # SecurityConfig, DataSeeder
    │   ├── controller/           # Auth, Product, Category, Cart, Order, Account
    │   ├── dto/                  # Records for requests/responses
    │   ├── entity/               # User, Product, Category, CartItem, Order, OrderItem
    │   ├── exception/            # GlobalExceptionHandler, ApiException, 404, JSON /error
    │   ├── mapper/               # Entity → DTO (prevents JSON cycles)
    │   ├── repository/           # Spring Data JPA repositories
    │   ├── security/             # JwtUtil, JwtAuthenticationFilter, CustomUserDetailsService
    │   └── service/              # AuthService, ProductService, CategoryService, CartService, OrderService
    ├── main/resources/
    │   ├── application.properties
    │   └── static/               # HTML pages, css/, js/, images/ (SVG)
    └── test/java/com/affiyamart/ # 86 unit & web-layer tests
```

## 🚀 Getting Started

### Prerequisites

- **JDK 17+** (works on newer JDKs too)
- **MySQL 8** running on `localhost:3306`
- No Maven install needed — use the included wrapper (`mvnw`)

### 1. Create the database

```bash
mysql -u root < database.sql
```

> This is **optional**: the datasource URL uses `createDatabaseIfNotExist=true` and the
> `DataSeeder` automatically seeds 5 categories, 15 products and 2 users when the tables
> are empty.

### 2. Check the configuration

`src/main/resources/application.properties`:

```properties
spring.datasource.username=root
spring.datasource.password=        # <- set your MySQL password here
app.jwt.secret=YWZmaXlhLW1hcnQt...# keep secret, >= 32 bytes for HS256
app.jwt.expiration-ms=86400000     # 24 h
```

### 3. Run the app

```powershell
# Windows PowerShell
.\mvnw.cmd spring-boot:run
```

```bash
# macOS / Linux
./mvnw spring-boot:run
```

Or press **F5** in VS Code (run config: `AffiyaMartApplication`).

Then open **http://localhost:8080**

### 4. Log in with a seeded account

| Role | Email | Password |
|------|-------|----------|
| 👑 Admin | `admin@affiyamart.com` | `admin123` |
| 🛒 Customer | `user@affiyamart.com` | `user123` |

## ✅ Running the Tests

```powershell
.\mvnw.cmd test        # Windows
./mvnw test            # macOS / Linux
```

**86 tests** — all pure unit / MockMvc tests (no MySQL needed):

- `service/*Test` — business rules: search & sort, stock checks, cart totals, checkout,
  order ownership, register/login/forgot-password, category CRUD guards
- `controller/*Test` — endpoint mapping, validation → 400 field errors, 404/409/401 JSON
- `security/JwtUtilTest` — token generation, tampering, expiry
- `mapper/MapperTest` — entity → DTO mapping and subtotal math

## 🔌 API Overview

Full request/response examples: [`requests.http`](requests.http) and [`curl-examples.sh`](curl-examples.sh).

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | public | Create account → JWT |
| POST | `/api/auth/login` | public | Login → JWT |
| POST | `/api/auth/forgot-password` | public | Issue temporary password |
| GET | `/api/auth/me` | JWT | Current profile |
| GET | `/api/auth/ping` | public | Health check |
| GET | `/api/products?search=&categoryId=&brand=&sort=` | public | List + filter + sort |
| GET | `/api/products/featured` · `/brands` · `/{id}` | public | Featured / brands / single |
| POST · PUT · DELETE | `/api/products[/{id}]` | ADMIN | Product CRUD |
| GET | `/api/categories[/{id}]` | public | Categories with product counts |
| POST · PUT · DELETE | `/api/categories[/{id}]` | ADMIN | Category CRUD |
| GET · POST | `/api/cart` | JWT | Read cart / add item |
| PUT · DELETE | `/api/cart/{id}` | JWT | Change quantity (0 = remove) / remove line |
| POST | `/api/orders` | JWT | Checkout from current cart |
| GET | `/api/orders` · `/all` · `/{orderNumber}` | JWT / ADMIN | Order history |
| GET | `/api/account` · `/cart-count` | JWT | Profile / navbar badge |

### Quick smoke test

```bash
curl http://localhost:8080/api/auth/ping
curl http://localhost:8080/api/products/featured

# get a token, then:
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@affiyamart.com","password":"user123"}'
```

## 🔐 Security Notes

- Stateless JWT filter; tokens carry `sub` (email), `name`, `role`, `uid`
- Passwords stored as **BCrypt** hashes only
- Method security via `@PreAuthorize("hasRole('ADMIN')")` on write endpoints
- Order lookups verify **ownership or admin role** (403 otherwise)
- Errors never leak stack traces — a `GlobalExceptionHandler` + JSON `/error` page keep
  every response structured

## 📌 Notes

- `spring.jpa.hibernate.ddl-auto=update` keeps existing data; run `database.sql` once for a
  clean schema + seed
- The forgot-password endpoint returns the temporary password in the response (demo mode —
  no SMTP required)

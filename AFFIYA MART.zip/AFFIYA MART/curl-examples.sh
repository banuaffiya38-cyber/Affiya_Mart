# curl examples for AFFIYA MART
# Run these in VS Code's terminal (Git Bash / WSL) or any shell.

HOST=http://localhost:8080

# ---------- 1. Server up? (no auth) ----------
curl $HOST/api/auth/ping

# ---------- 2. Register ----------
curl -X POST $HOST/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Fazz","phone":"9876543210","email":"fazz@example.com",
       "password":"secret123","confirmPassword":"secret123"}'

# ---------- 3. Login (seeded admin) -> copy the token ----------
curl -X POST $HOST/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@affiyamart.com","password":"admin123"}'

# Save the token, then:
TOKEN="PASTE_TOKEN_HERE"

# ---------- 4. Read products (public) ----------
curl "$HOST/api/products?search=dairy&sort=price-asc"
curl "$HOST/api/products/featured"
curl "$HOST/api/categories"

# ---------- 5. CREATE product (admin) ----------
curl -X POST $HOST/api/products \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"Mars Bar","brand":"Mars","price":45.00,"rating":4.5,"stock":100,
       "imageUrl":"images/snickers.svg","description":"Caramel and nougat.",
       "featured":true,"categoryId":1}'

# ---------- 6. UPDATE product ----------
curl -X PUT $HOST/api/products/1 \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"Dairy Milk Silk","brand":"Cadbury","price":95.00,"rating":4.8,
       "stock":150,"imageUrl":"images/dairymilk.svg","description":"Silky smooth.",
       "featured":true,"categoryId":1}'

# ---------- 7. DELETE product ----------
curl -X DELETE $HOST/api/products/15 -H "Authorization: Bearer $TOKEN"

# ---------- 8. Cart ----------
curl $HOST/api/cart -H "Authorization: Bearer $TOKEN"
curl -X POST $HOST/api/cart -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" -d '{"productId":1,"quantity":2}'
curl -X PUT  $HOST/api/cart/1 -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" -d '{"quantity":3}'
curl -X DELETE $HOST/api/cart/1 -H "Authorization: Bearer $TOKEN"

# ---------- 9. Checkout -> Order ID ----------
curl -X POST $HOST/api/orders -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"customerName":"Fazz","phone":"9876543210","email":"fazz@example.com",
       "address":"12 Cocoa Lane","city":"Chennai","pincode":"600001"}'

# ---------- 10. Order history ----------
curl $HOST/api/orders -H "Authorization: Bearer $TOKEN"

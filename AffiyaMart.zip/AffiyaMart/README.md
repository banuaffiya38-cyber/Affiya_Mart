# AFFIYA MART
Professional pure-frontend supermarket demo.

## Run
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Install Live Server extension if needed.
4. Right-click `index.html` → Open with Live Server.

No backend, database, Java, Node or server-side code is required.

Features include product browsing, 120+ generated product records, category/search UI, cart, wishlist, demo login/register, checkout, orders, tracking and admin dashboard using localStorage.
